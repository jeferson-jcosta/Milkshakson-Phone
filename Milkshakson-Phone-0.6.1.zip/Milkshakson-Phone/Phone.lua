-- Milkshakson - Phone
-- The chat as a phone messenger: a list of conversations (players, group,
-- guild, channels) and one conversation open at a time, in bubbles.
local ADDON, ns = ...
local L = ns.L
local Store, Route = ns.Store, ns.Route

local PREFIX = "|cff25d366[Phone]|r "
local MASK = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local CLASS_TEX = "Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES"
local STATUS_H, HEAD_H, INPUT_H, ROW_H, LIST_W = 18, 42, 30, 46, 200
local COLL_W = 64 -- chats list collapsed (drawer): icons only
local SEARCH_H = 30 -- row under the top bar: drawer arrow + search box (hidden while minimized)
local MINI_ROW = 30 -- minimized: second row under the top bar: "Chats (n)" + the unread pills
local TOP_H = 34  -- top bar: professions (icon + level, click opens it), options, -/+; minimized: title + pills
local PAGE = 50 -- messages drawn at first; more when scrolling to the top

-- Dark messenger palette.
local COL = {
    bg = { 0.043, 0.078, 0.098 }, status = { 0.02, 0.04, 0.05 }, head = { 0.122, 0.173, 0.2 },
    inB = { 0.122, 0.173, 0.2 }, outB = { 0.0, 0.361, 0.294 }, info = { 0.09, 0.14, 0.16 },
    text = { 0.91, 0.93, 0.94 }, sub = { 0.53, 0.59, 0.63 }, accent = { 0.145, 0.827, 0.4 },
    sep = { 0.14, 0.19, 0.21 }, input = { 0.165, 0.224, 0.259 }, warn = { 0.55, 0.32, 0.05 },
    ring = { 0.25, 0.35, 0.4 },
}
local settings

-- Themes (settings.theme): auto = your faction, alliance (navy + gold), horde
-- (dark red + amber), messenger (the original green). The colors are changed in
-- place inside COL, so everything drawn with a COL color is repainted (Paint).
local PALETTES = {
    alliance = {
        bg = { 0.035, 0.051, 0.086 }, status = { 0.02, 0.03, 0.055 }, head = { 0.067, 0.098, 0.157 },
        inB = { 0.106, 0.149, 0.235 }, outB = { 0.118, 0.29, 0.58 }, info = { 0.067, 0.094, 0.149 },
        text = { 0.92, 0.94, 0.97 }, sub = { 0.56, 0.63, 0.73 }, accent = { 0.98, 0.78, 0.27 },
        sep = { 0.11, 0.15, 0.22 }, input = { 0.09, 0.13, 0.2 }, ring = { 0.85, 0.68, 0.25 },
    },
    horde = {
        bg = { 0.075, 0.035, 0.035 }, status = { 0.05, 0.02, 0.02 }, head = { 0.15, 0.065, 0.06 },
        inB = { 0.2, 0.1, 0.09 }, outB = { 0.52, 0.13, 0.1 }, info = { 0.13, 0.06, 0.055 },
        text = { 0.96, 0.92, 0.9 }, sub = { 0.72, 0.6, 0.56 }, accent = { 1, 0.6, 0.18 },
        sep = { 0.22, 0.11, 0.1 }, input = { 0.18, 0.09, 0.08 }, ring = { 0.85, 0.32, 0.18 },
    },
    messenger = {},
}
for k, v in pairs(COL) do PALETTES.messenger[k] = { v[1], v[2], v[3] } end
local CREST = { alliance = "Interface\\Timer\\Alliance-Logo", horde = "Interface\\Timer\\Horde-Logo" }
local COLSET = {}
for _, v in pairs(COL) do COLSET[v] = true end
local painted = {}   -- { texture, COL color, alpha }

local function ThemeName()
    local t = settings and settings.theme or "auto"
    if t == "auto" then
        local f = UnitFactionGroup and UnitFactionGroup("player")
        t = f == "Horde" and "horde" or "alliance"
    end
    return PALETTES[t] and t or "alliance"
end
ns.ThemeName = ThemeName

local function UseTheme(name)
    for k, v in pairs(PALETTES[name] or {}) do
        local c = COL[k]
        if c then c[1], c[2], c[3] = v[1], v[2], v[3] end
    end
end

-- Text colors per chat type: the game's own (ChatTypeInfo, follows the
-- player's chat color settings), with the default colors as fallback.
local TYPE_COL = {
    GUILD = { 0.25, 1, 0.25 }, GUILD_ACHIEVEMENT = { 0.25, 1, 0.25 }, OFFICER = { 0.25, 0.75, 0.25 },
    PARTY = { 0.67, 0.67, 1 }, PARTY_LEADER = { 0.46, 0.78, 1 },
    RAID = { 1, 0.5, 0 }, RAID_LEADER = { 1, 0.28, 0.04 }, RAID_WARNING = { 1, 0.28, 0 },
    INSTANCE_CHAT = { 1, 0.5, 0 }, INSTANCE_CHAT_LEADER = { 1, 0.86, 0.73 },
    WHISPER = { 1, 0.5, 1 }, WHISPER_INFORM = { 1, 0.5, 1 }, AFK = { 1, 0.5, 1 }, DND = { 1, 0.5, 1 },
    BN_WHISPER = { 0, 1, 0.96 }, BN_WHISPER_INFORM = { 0, 1, 0.96 },
    SAY = { 1, 1, 1 }, YELL = { 1, 0.25, 0.25 }, EMOTE = { 1, 0.5, 0.25 }, TEXT_EMOTE = { 1, 0.5, 0.25 },
    CHANNEL = { 1, 0.75, 0.75 }, SYSTEM = { 1, 1, 0 },
    MONSTER_SAY = { 1, 1, 0.62 }, MONSTER_YELL = { 1, 0.25, 0.25 }, MONSTER_EMOTE = { 1, 0.5, 0.25 },
}

local function TypeColor(m, c)
    if not (settings and settings.typeColors) or not m then return nil end
    local ev = m.ev or ""
    if ev == "CHANNEL" and c and c.chan then
        local info = ChatTypeInfo and ChatTypeInfo["CHANNEL" .. c.chan]
        if info and info.r then return { info.r, info.g, info.b } end
    end
    local info = ChatTypeInfo and ChatTypeInfo[ev]
    if info and info.r then return { info.r, info.g, info.b } end
    if TYPE_COL[ev] then return TYPE_COL[ev] end
    if c and (c.kind == "system" or c.kind == "addon") then return TYPE_COL.SYSTEM end
end
ns.TypeColor = TypeColor


local KIND_ICON = {
    whisper = "Interface\\Icons\\INV_Misc_QuestionMark", bn = "Interface\\Icons\\INV_Misc_Note_06",
    guild = "Interface\\Icons\\INV_Shirt_GuildTabard_01", officer = "Interface\\Icons\\INV_Shirt_GuildTabard_01",
    party = "Interface\\Icons\\Ability_Warrior_RallyingCry", raid = "Interface\\Icons\\Ability_Warrior_BattleShout",
    instance = "Interface\\Icons\\INV_Misc_Key_03", ["local"] = "Interface\\Icons\\INV_Misc_GroupNeedMore",
    channel = "Interface\\Icons\\INV_Letter_15", system = "Interface\\Icons\\INV_Misc_Gear_01",
    archive = "Interface\\Icons\\INV_Box_01", back = "Interface\\Icons\\Spell_ChargeNegative",
    npc = "Interface\\Icons\\Ability_Hunter_BeastCall", combat = "Interface\\Icons\\Ability_DualWield",
    rolls = "Interface\\Buttons\\UI-GroupLoot-Dice-Up",
    skills = "Interface\\Icons\\Trade_Engineering",
    auction = "Interface\\Icons\\INV_Misc_Coin_02",
}
-- Channel icons by name (any client language): business, defense, zone map.
local CHANNEL_ICON = {
    { "Interface\\Icons\\INV_Misc_Coin_01", { "trade", "comércio", "comercio", "handel", "commerce" } },
    { "Interface\\Icons\\INV_Sword_04", { "defense", "defesa", "defensa", "verteidigung", "défense" } },
    { "Interface\\Icons\\INV_Misc_Map_01", { "general", "geral", "allgemein", "général" } },
}
local function ChannelIcon(name)
    name = (name or ""):lower()
    for _, x in ipairs(CHANNEL_ICON) do
        for _, w in ipairs(x[2]) do
            if name:find(w, 1, true) then return x[1] end
        end
    end
end
local SEND_TYPE = { party = "PARTY", raid = "RAID", instance = "INSTANCE_CHAT", guild = "GUILD", officer = "OFFICER", ["local"] = "SAY" }

local phone, clockText, zoneText, banner, grip
local moneyText
local listView, listTitle, listScroll, listContent, emptyText, listHead, searchBox
local chatView, chatTitle, chatSub, chatIcon, chatScroll, chatContent
local chatRing, crest
local inputBar, inputText
local rows, bubbles, seps = {}, {}, {}
local openKey
local profBar, searchRow

local function Num(v, d) return type(v) == "number" and v or d end

-- Errors are shown on the phone itself (the game's chat may be hidden and
-- script errors are often turned off): red text over the chat, click to close.
local errorBox
local function ShowError(err)
    err = tostring(err)
    if settings then
        settings.errors = (settings.errors or 0) + 1
        settings.lastError = err
    end
    if errorBox then
        errorBox.text:SetText("|cffff5050Milkshakson-Phone error|r (click to close)\n" .. err)
        errorBox:Show()
    else
        print("|cffff5050[Phone] error:|r " .. err)
    end
end
ns.ShowError = ShowError

-- Information on the phone (same box, not an error).
local function Notice(title, text)
    if errorBox then
        errorBox.text:SetText("|cff25d366" .. title .. "|r\n\n" .. text .. "\n\n|cff888888(click to close)|r")
        errorBox:Show()
    end
end
ns.Notice = Notice

local function Trace(e)
    return tostring(e) .. "\n" .. ((debugstack and debugstack(2, 8, 0)) or "")
end

-- Runs f(...) and shows any error instead of failing silently.
local function Safe(f, ...)
    local ok, err = xpcall(f, Trace, ...)
    if not ok then ShowError(err) end
    return ok
end
ns.Safe = Safe

local function Paint(t, c, a)
    t:SetColorTexture(c[1], c[2], c[3], a or 1)
    if COLSET[c] then painted[#painted + 1] = { t, c, a or 1 } end
    return t
end

local function Tex(parent, layer, c, a, sub)
    return Paint(parent:CreateTexture(nil, layer or "BACKGROUND", nil, sub), c, a)
end

-- Every text of the phone, with its template size, so the font size option
-- (settings.fontScale) can be applied to all of them at once.
local fonts = {}
local function FontScale() return tonumber(settings and settings.fontScale) or 1 end

-- Messages (bubbles, day lines) have their own size (settings.chatFontScale);
-- until it is set they follow the phone's size.
local function ChatFontScale() return tonumber(settings and settings.chatFontScale) or FontScale() end
local function ScaleOf(f) return (rawget(f, "group") == "chat") and ChatFontScale() or FontScale() end

local function ScaleFont(f)
    local path, size, flags = f:GetFont()
    if type(size) ~= "number" or not path then return end
    f.baseSize = rawget(f, "baseSize") or size
    f:SetFont(path, f.baseSize * ScaleOf(f), flags or "")
end

local function Font(parent, template, c, justify, group)
    local f = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    if c then f:SetTextColor(c[1], c[2], c[3]) end
    if c and COLSET[c] then f.col = c end
    f:SetJustifyH(justify or "LEFT")
    f.group = group
    fonts[#fonts + 1] = f
    if ScaleOf(f) ~= 1 then ScaleFont(f) end
    return f
end

ns.Font = Font

local function RowH() return math.floor(ROW_H * math.max(1, FontScale()) + 0.5) end
ns.Fonts, ns.RowH = fonts, RowH
local function ListW() return (settings and settings.listCollapsed) and COLL_W or LIST_W end
ns.ListW = ListW

local function ClassColor(cls)
    if not cls then return nil end
    local c = (C_ClassColor and C_ClassColor.GetClassColor and C_ClassColor.GetClassColor(cls))
        or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls])
    if type(c) == "table" and c.r then return { c.r, c.g, c.b } end
end

-- Color of a chat's name (list and header): class color for a player, the
-- chat type's color for groups and channels (guild green, party blue...).
local KIND_EV = { guild = "GUILD", officer = "OFFICER", party = "PARTY", raid = "RAID",
    instance = "INSTANCE_CHAT", bn = "BN_WHISPER" }
local function NameColor(c)
    if c.kind == "whisper" then
        return ClassColor(c.cls) or (settings.typeColors and TypeColor({ ev = "WHISPER" }, c)) or COL.text
    end
    if not settings.typeColors then return COL.text end
    if c.kind == "channel" then return TypeColor({ ev = "CHANNEL" }, c) or COL.text end
    local ev = KIND_EV[c.kind]
    return ev and TypeColor({ ev = ev }, c) or COL.text
end
ns.NameColor = NameColor

local function Title(c)
    if c.kind == "archive" then return L.ARCHIVED_N:format(c.n or 0) end
    if c.kind == "back" then return L.BACK end
    if c.kind == "whisper" or c.kind == "bn" or c.kind == "channel" then return c.name or "?" end
    return L["K_" .. c.kind]
end
ns.Title = Title

local function IsGroup(kind) return kind ~= "whisper" and kind ~= "bn" end

-- Professions with their level, in their own row under the top bar (icon +
-- "155/225" each; name on hover). Modern API (GetProfessions) first, else the
-- skills list (classic API: profession and secondary skill headers).
local function SpellIcon(name)
    local ok, t
    if C_Spell and C_Spell.GetSpellTexture then ok, t = pcall(C_Spell.GetSpellTexture, name) end
    if not (ok and t) and GetSpellTexture then ok, t = pcall(GetSpellTexture, name) end
    return ok and t or nil
end

local function ProfList()
    local out = {}
    if GetProfessions and GetProfessionInfo then
        local list = { GetProfessions() }
        for i = 1, 6 do
            local idx = list[i]
            if idx then
                local ok, name, icon, rank, max = pcall(GetProfessionInfo, idx)
                if ok and name and rank and max and max > 0 then out[#out + 1] = { name, rank, max, icon } end
            end
        end
    end
    if #out == 0 and GetNumSkillLines and GetSkillLineInfo then
        local want = { [TRADE_SKILLS or "Professions"] = true, [SECONDARY_SKILLS or "Secondary Skills"] = true }
        local inside = false
        for i = 1, GetNumSkillLines() or 0 do
            local name, header, _, rank, _, _, max = GetSkillLineInfo(i)
            if header then
                inside = want[name] or false
            elseif inside and name and rank and max and max > 0 then
                out[#out + 1] = { name, rank, max }
            end
        end
    end
    for _, p in ipairs(out) do p[4] = p[4] or SpellIcon(p[1]) or 134400 end
    return out
end
ns.ProfList = ProfList

local function Professions()
    local out = ProfList()
    local parts = {}
    for _, p in ipairs(out) do parts[#parts + 1] = ("%s %d/%d"):format(p[1], p[2], p[3]) end
    return table.concat(parts, "  -  ")
end
ns.Professions = Professions

-- What a click on a profession casts: its own spell opens its window (Mining's
-- window is Smelting). Gathering skills with no window (Herbalism, Skinning) do nothing.
local SMELTING = 2656
local function ProfSpell(name)
    local mining = (C_Spell and C_Spell.GetSpellInfo) and select(2, pcall(C_Spell.GetSpellInfo, 2575))
    if type(mining) == "table" and mining.name == name then
        local sm = select(2, pcall(C_Spell.GetSpellInfo, SMELTING))
        if type(sm) == "table" and sm.name then return sm.name end
    end
    return name
end

-- Clicks go to secure buttons (casting a spell is protected), parented to
-- UIParent (a protected child would make the phone itself protected: it hides
-- and minimizes in combat) and laid over the icons out of combat; a state
-- driver hides them in combat.
-- Minimized height: status + top bar (professions + buttons) + the "Chats" / pills row.
local function MiniH()
    return STATUS_H + TOP_H + MINI_ROW
end
ns.MiniH = MiniH

local profPending = false
function ns:SyncProfButtons()
    if not profBar then return end
    if InCombatLockdown and InCombatLockdown() then profPending = true; return end
    profPending = false
    local items = rawget(profBar, "items") or {}
    for _, it in ipairs(items) do
        local b = rawget(it, "click")
        if b then
            local show = it:IsShown() and profBar:IsVisible() and it.spell ~= nil
            b:ClearAllPoints()
            b:SetAllPoints(it)
            b:SetAttribute("type", "spell")
            b:SetAttribute("spell", it.spell)
            b:SetShown(show and true or false)
        end
    end
end

-- Level state of a profession, against the real cap (300 on Forever; ranks
-- Apprentice 75 / Journeyman 150 / Expert 225 / Artisan 300):
--   "max"   = 300/300 (green)
--   "low"   = under 40% of 300 (red), whatever the rank
--   "train" = the next rank can be learned now (blue, "200/225+"): skill within
--             25 of the rank's top and character level 10 / 20 / 35
--   nil     = normal
local PROF_CAP, PROF_LOW = 300, 0.4
local NEXT_LEVEL = { [75] = 10, [150] = 20, [225] = 35 }
local PROF_COL = { max = { 0.3, 1, 0.35 }, train = { 0.35, 0.68, 1 }, low = { 1, 0.32, 0.3 } }
local function ProfState(rank, max)
    local cap = math.max(PROF_CAP, max)
    if rank >= cap then return "max" end
    if rank < cap * PROF_LOW then return "low" end
    local need = NEXT_LEVEL[max]
    local lvl = UnitLevel and UnitLevel("player") or 0
    if need and rank >= max - 25 and lvl >= need then return "train" end
    return nil
end
ns.ProfState = ProfState

local function ProfItem(i)
    local it = CreateFrame("Frame", nil, profBar)
    it:SetHeight(TOP_H - 8)
    -- round icon with a thin ring, like the chats list (crop first, then the mask)
    it.ring = Tex(it, "ARTWORK", COL.ring, 0.9, -1)
    it.ring:SetSize(22, 22)
    it.ring:SetPoint("LEFT", 0, 0)
    ns.Round(it.ring)
    it.icon = it:CreateTexture(nil, "ARTWORK")
    it.icon:SetSize(20, 20)
    it.icon:SetPoint("CENTER", it.ring, "CENTER")
    pcall(it.icon.SetTexCoord, it.icon, 0.08, 0.92, 0.08, 0.92)
    ns.RoundIcon(it.icon)
    it.text = Font(it, "GameFontHighlightSmall", COL.text)
    it.text:SetPoint("LEFT", it.ring, "RIGHT", 5, 0)
    local b = CreateFrame("Button", "MilkshaksonPhoneProf" .. i, UIParent, "SecureActionButtonTemplate")
    b:SetFrameStrata(phone and phone:GetFrameStrata() or "LOW")
    b:SetFrameLevel((profBar:GetFrameLevel() or 1) + 20)
    b:RegisterForClicks("AnyUp", "AnyDown")
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.08)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText(it.name or "")
        GameTooltip:AddLine(it.level or "", 1, 1, 1)
        local hint = it.state and L["PROF_" .. it.state:upper()]
        if hint then
            local c = PROF_COL[it.state]
            GameTooltip:AddLine(hint, c[1], c[2], c[3], true)
        end
        -- trainers visited for it: where, and the ranks they teach
        if ns.Trainers then
            local lines = ns.Trainers:Lines(it.name, 3)
            if #lines > 0 then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(L.PROF_TRAINERS, 1, 0.82, 0)
                for _, l in ipairs(lines) do
                    GameTooltip:AddLine(l[1], 1, 1, 1, true)
                    if l[2] then GameTooltip:AddLine("   " .. L.PROF_TEACHES:format(l[2]), 0.6, 0.6, 0.6, true) end
                end
            elseif it.state == "train" then
                GameTooltip:AddLine(L.PROF_NO_TRAINER, 0.7, 0.7, 0.7, true)
            end
        end
        if it.spell then GameTooltip:AddLine(L.PROF_CLICK, 0.6, 0.6, 0.6) end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    b:Hide()
    if RegisterStateDriver then pcall(RegisterStateDriver, b, "visibility", "[combat] hide; show") end
    it.click = b
    return it
end

-- Money as in the bags: amounts with the gold / silver / copper coin icons
-- (never "1g 2s 3c"). Silver shows once there is gold, copper always.
local COIN = {
    g = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t",
    s = "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t",
    c = "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
}
local function Coins(c)
    c = math.floor(math.abs(tonumber(c) or 0) + 0.5)
    local g, sv, cp = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    local t = {}
    if g > 0 then t[#t + 1] = (BreakUpLargeNumbers and BreakUpLargeNumbers(g) or g) .. COIN.g end
    if g > 0 or sv > 0 then t[#t + 1] = sv .. COIN.s end
    t[#t + 1] = cp .. COIN.c
    return table.concat(t, " ")
end
ns.Coins, ns.MoneyText = Coins, Coins

-- Money written as words in a message ("3 Silver, 20 Copper", the game's
-- GOLD_AMOUNT / SILVER_AMOUNT / COPPER_AMOUNT) -> coin icons. Addon / system
-- lines also turn "1g 2s 3c" into icons.
local coinPats
local function CoinPatterns()
    if coinPats and #coinPats > 0 then return coinPats end
    coinPats = {}
    for _, e in ipairs({ { GOLD_AMOUNT, "g" }, { SILVER_AMOUNT, "s" }, { COPPER_AMOUNT, "c" } }) do
        if type(e[1]) == "string" and e[1]:find("%%d") then
            local pat = e[1]:gsub("%%%d%$", "%%"):gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%d", "(%%d+)")
            coinPats[#coinPats + 1] = { pat, e[2] }
        end
    end
    return coinPats
end
local function CoinIcons(t, letters)
    if type(t) ~= "string" or t == "" then return t end
    for _, p in ipairs(CoinPatterns()) do
        t = t:gsub(p[1], function(n) return n .. COIN[p[2]] end)
    end
    if letters then
        t = t:gsub("(%f[%w]%d+)([gsc])%f[^%w]", function(n, k) return n .. COIN[k] end)
    end
    return t
end
ns.CoinIcons = CoinIcons

function ns:UpdateProfessions()
    if not profBar then return end
    local on = not (settings and settings.showProfLevels == false)
    local list = on and ProfList() or {}
    profBar.items = rawget(profBar, "items") or {}
    local x = 12
    for i, p in ipairs(list) do
        local it = profBar.items[i]
        if not it then
            -- new secure buttons only out of combat
            if InCombatLockdown and InCombatLockdown() then profPending = true; break end
            it = ProfItem(i)
            profBar.items[i] = it
        end
        it.name, it.level = p[1], ("%d/%d"):format(p[2], p[3])
        it.spell = ProfSpell(p[1])
        it.icon:SetTexture(p[4])
        it.text:SetText(it.level)
        -- green = top rank maxed, blue + = maxed, learn the next rank, red = very low
        it.state = ProfState(p[2], p[3])
        if it.state == "train" then it.level = it.level .. "+"; it.text:SetText(it.level) end
        local c = PROF_COL[it.state] or COL.text
        it.text:SetTextColor(c[1], c[2], c[3])
        local w = 27 + math.max(30, tonumber(it.text:GetStringWidth()) or 40)
        it:SetWidth(w)
        it:ClearAllPoints()
        it:SetPoint("LEFT", profBar, "LEFT", x, 0)
        x = x + w + 16
        it:Show()
    end
    for i = #list + 1, #profBar.items do profBar.items[i]:Hide() end
    ns.profWidth = (#list > 0) and (x - 16 + 12) or 0
    ns:SyncProfButtons()
end

local function Sub(c)
    local s
    if c.kind == "whisper" then s = L.SUB_WHISPER
    elseif c.kind == "bn" then s = L.SUB_BN
    elseif c.kind == "channel" then s = c.chan and L.SUB_CHANNEL:format(c.chan) or L.SUB_GROUP
    elseif c.kind == "system" or c.kind == "npc" or c.kind == "addon" or c.kind == "rolls"
        or c.kind == "auction" or c.kind == "skills" then s = L.SUB_READONLY
    else s = L.SUB_GROUP end
    if c.muted then s = s .. "  -  " .. L.MUTED end
    return s
end

local function Today(t) return date("%Y%m%d", t) end
local function Clock(t) return date("%H:%M", t) end
local function DayLabel(t)
    local d = Today(t)
    if d == Today(time()) then return L.TODAY end
    if d == Today(time() - 86400) then return L.YESTERDAY end
    return date("%d/%m/%Y", t)
end
local function ListTime(t)
    local d = Today(t)
    if d == Today(time()) then return Clock(t) end
    if d == Today(time() - 86400) then return L.YESTERDAY end
    return date("%d/%m", t)
end

local function OneLine(s) return ((s or ""):gsub("[\r\n]+", " ")) end

-- Message text with its tag ([!], [AFK]...).
local LETTER_KINDS = { addon = true, auction = true, system = true, npc = true, rolls = true, skills = true }
local function Body(m, kind)
    local s = m.text or ""
    if not (issecretvalue and issecretvalue(s)) then
        s = CoinIcons(s, LETTER_KINDS[kind or ""] or m.npc or false)
    end
    if m.ev == "EMOTE" and m.from then s = m.from .. " " .. s end
    if m.tag == "warning" then s = "|cffff8000" .. L.TAG_WARNING .. "|r " .. s
    elseif m.tag == "afk" then s = L.TAG_AFK .. " " .. s
    elseif m.tag == "dnd" then s = L.TAG_DND .. " " .. s
    elseif m.tag == "yell" then s = "|cffff5050" .. s .. "|r" end
    return s
end

-- Mine: marked when received, or (older messages) from my name as the chat writes it.
local function IsMine(m)
    if m.out then return true end
    local me = Route.myName or (Store:Char() and Store:Char().me)
    return me ~= nil and m.from == me and not m.npc
end
ns.IsMine = IsMine

-- Search (the box at the top of the chats list): ns.query, lower case.
local function Plain(t)
    return ((t or ""):gsub("|H.-|h(.-)|h", "%1"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""))
end
local function Matches(m, q)
    if not q then return true end
    return Plain(m.text):lower():find(q, 1, true) ~= nil or ((m.from or ""):lower():find(q, 1, true) ~= nil)
end
ns.Matches = Matches

-- The search term in yellow (only in text without links / codes, to keep them intact).
local function Highlight(s, q)
    if not q or s:find("|", 1, true) then return s end
    local low, out, i = s:lower(), {}, 1
    while true do
        local a, b = low:find(q, i, true)
        if not a then break end
        out[#out + 1] = s:sub(i, a - 1) .. "|cffffd100" .. s:sub(a, b) .. "|r"
        i = b + 1
    end
    out[#out + 1] = s:sub(i)
    return table.concat(out)
end

local function Preview(c, m)
    if m.skill and m.rank then return L.SKILL_UP:format(m.skill, m.rank) end
    local s = OneLine(Body(m, c and c.kind))
    if IsMine(m) then return L.YOU .. ": " .. s end
    if IsGroup(c.kind) and m.from and not m.info then return m.from .. ": " .. s end
    return s
end

-- Round icons: a circle mask (MaskTexture). This client refuses SetTexCoord on a
-- masked texture, so the mask is taken off, the crop set, and the mask put back.
local function RoundIcon(tex)
    local p = tex:GetParent()
    if not (p and p.CreateMaskTexture and tex.AddMaskTexture) then return nil end
    local ok, m = pcall(p.CreateMaskTexture, p)
    if not ok or not m then return nil end
    pcall(m.SetTexture, m, MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    m:SetAllPoints(tex)
    tex.roundMask = m
    pcall(tex.AddMaskTexture, tex, m)
    return m
end
ns.RoundIcon = RoundIcon

local function SetIcon(tex, c)
    local m = rawget(tex, "roundMask")
    if m and tex.RemoveMaskTexture then pcall(tex.RemoveMaskTexture, tex, m) end
    local coords = c.cls and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[c.cls]
    if coords and c.kind == "whisper" then
        tex:SetTexture(CLASS_TEX)
        pcall(tex.SetTexCoord, tex, coords[1], coords[2], coords[3], coords[4])
    else
        tex:SetTexture((c.kind == "channel" and ChannelIcon(c.name)) or c.icon or KIND_ICON[c.kind] or KIND_ICON.whisper)
        pcall(tex.SetTexCoord, tex, 0.08, 0.92, 0.08, 0.92)
    end
    if m then pcall(tex.AddMaskTexture, tex, m) end
end

ns.SetIcon = SetIcon

-- Round solid shapes (ring, badge): the same circle MaskTexture as the icons
-- (SetMask did nothing on this client: rings and badges stayed square, 2026-11-27).
local function Round(tex)
    if not RoundIcon(tex) and tex.SetMask then pcall(tex.SetMask, tex, MASK) end
end
ns.Round = Round

-- Collapse / expand button (the game's -/+ buttons, as in ReadyQuests).
local minButtons = {}
local function MinButton(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(18, 18)
    b:SetHighlightTexture("Interface\\Buttons\\UI-PlusButton-Hilight", "ADD")
    b:SetScript("OnClick", function() ns:Minimize() end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(L.TIP_MIN)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    minButtons[#minButtons + 1] = b
    return b
end

-- "-" while open, "+" while minimized.
local function UpdateMinButtons(min)
    local tex = min and "Interface\\Buttons\\UI-PlusButton-" or "Interface\\Buttons\\UI-MinusButton-"
    for _, b in ipairs(minButtons) do
        b:SetNormalTexture(tex .. "Up")
        b:SetPushedTexture(tex .. "Down")
    end
end

local function Scroller(parent, onTop)
    local s = CreateFrame("ScrollFrame", nil, parent)
    local c = CreateFrame("Frame", nil, s)
    c:SetSize(10, 10)
    s:SetScrollChild(c)
    s:EnableMouseWheel(true)
    s:SetScript("OnMouseWheel", function(self, d)
        local max = Num(self:GetVerticalScrollRange(), 0)
        local v = Num(self:GetVerticalScroll(), 0)
        if d > 0 and v <= 0 and onTop then onTop() return end
        self:SetVerticalScroll(math.max(0, math.min(max, v - d * 48)))
    end)
    s:SetScript("OnSizeChanged", function(_, w) if Num(w, 0) > 1 then c:SetWidth(w) end end)
    return s, c
end

-- Thin scroll bar at the right of a scroll frame: thumb sized to the visible part,
-- drag it or click the track; the wheel over it scrolls too. Hidden when all fits.
local function ScrollBar(s, onTop)
    local bar = CreateFrame("Slider", nil, s:GetParent())
    bar:SetWidth(6)
    bar:SetPoint("TOPLEFT", s, "TOPRIGHT", 2, -2)
    bar:SetPoint("BOTTOMLEFT", s, "BOTTOMRIGHT", 2, 2)
    bar:SetOrientation("VERTICAL")
    bar:SetMinMaxValues(0, 0)
    bar:SetValue(0)
    if bar.SetObeyStepOnDrag then bar:SetObeyStepOnDrag(false) end
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetAllPoints()
    track:SetColorTexture(1, 1, 1, 0.05)
    local thumb = bar:CreateTexture(nil, "OVERLAY")
    thumb:SetColorTexture(COL.sub[1], COL.sub[2], COL.sub[3], 0.6)
    thumb:SetSize(6, 30)
    bar:SetThumbTexture(thumb)
    bar.thumb = thumb
    bar:SetScript("OnValueChanged", function(self, v)
        if self.sync then return end
        s:SetVerticalScroll(v)
    end)
    -- dragged up to the top: older messages, like the wheel at the top
    bar:SetScript("OnMouseUp", function(self)
        if onTop and Num(self:GetValue(), 1) <= 0 then onTop() end
    end)
    bar:EnableMouseWheel(true)
    bar:SetScript("OnMouseWheel", function(_, d)
        local f = s:GetScript("OnMouseWheel")
        if f then f(s, d) end
    end)
    bar:SetScript("OnEnter", function() thumb:SetColorTexture(COL.text[1], COL.text[2], COL.text[3], 0.8) end)
    bar:SetScript("OnLeave", function() thumb:SetColorTexture(COL.sub[1], COL.sub[2], COL.sub[3], 0.6) end)
    local function Sync()
        local r, h = Num(s:GetVerticalScrollRange(), 0), Num(s:GetHeight(), 0)
        bar.sync = true
        bar:SetMinMaxValues(0, math.max(0, r))
        bar:SetValue(Num(s:GetVerticalScroll(), 0))
        bar.sync = false
        if r <= 1 or h <= 0 then bar:Hide() return end
        bar:Show()
        thumb:SetHeight(math.max(18, math.floor(h * h / (h + r))))
    end
    s:HookScript("OnVerticalScroll", Sync)
    s:HookScript("OnScrollRangeChanged", Sync)
    s:HookScript("OnSizeChanged", Sync)
    bar.Sync = Sync
    bar:Hide()
    return bar
end

---------------------------------------------------------------------------
-- The game's edit box (typing stays with the game: slash commands, links,
-- channels and whisper targets all work as usual)
---------------------------------------------------------------------------
local function EditBox() return (ChatFrame1 and ChatFrame1.editBox) or _G.ChatFrame1EditBox end

local function ChatTarget(c)
    if not c then return end
    if c.kind == "whisper" then return "WHISPER", c.target or c.name end
    if c.kind == "bn" then return "BN_WHISPER", c.target or c.name end
    if c.kind == "channel" then if c.chan then return "CHANNEL", c.chan end return end
    return SEND_TYPE[c.kind]
end
ns.ChatTarget = ChatTarget

-- Make the open conversation the edit box's current/sticky target.
function ns:SetSticky(c)
    local e = EditBox()
    local t, target = ChatTarget(c)
    if not (e and t) then return false end
    e:SetAttribute("chatType", t)
    e:SetAttribute("stickyType", t)
    if t == "WHISPER" or t == "BN_WHISPER" then e:SetAttribute("tellTarget", target) end
    if t == "CHANNEL" then e:SetAttribute("channelTarget", target) end
    local upd = ChatEdit_UpdateHeader or (ChatFrameUtil and ChatFrameUtil.UpdateHeader)
    if upd and e:IsShown() then pcall(upd, e) end
    return true
end

function ns:Compose()
    local c = Store:Get(openKey)
    if c then ns:SetSticky(c) end
    local open = ChatFrame_OpenChat or (ChatFrameUtil and ChatFrameUtil.OpenChat)
    if open then pcall(open, "", ChatFrame1) end
end

-- Where the docked typing box sits: on the input bar, or (minimized) below the
-- phone, outside its clipped area, so it covers neither the pills nor the + button.
function ns:PlaceEditBox(min)
    local e = ns.docked and EditBox()
    if not e then return end
    e:ClearAllPoints()
    if min == "header" then -- typing while minimized: over the header, the phone stays small
        e:SetPoint("TOPLEFT", phone, "TOPLEFT", 4, -STATUS_H - 4)
        e:SetPoint("BOTTOMRIGHT", phone, "TOPRIGHT", -4, -STATUS_H - TOP_H + 4)
    elseif min then
        e:SetPoint("TOPLEFT", phone, "BOTTOMLEFT", 0, -40)
        e:SetPoint("TOPRIGHT", phone, "BOTTOMRIGHT", 0, -40)
    else
        e:SetPoint("TOPLEFT", inputBar, "TOPLEFT", -2, 2)
        e:SetPoint("BOTTOMRIGHT", inputBar, "BOTTOMRIGHT", 2, -2)
    end
end

-- Typing box for the current state: on the bar (open), over the header (minimized
-- and typing), or out of the way (minimized, not typing).
function ns:SyncEditBox(min)
    local e = ns.docked and EditBox()
    if not e then return end
    if min == nil then min = settings.min and not ns.peek end
    local typing = e.HasFocus and e:HasFocus()
    if not min then
        ns:PlaceEditBox(false)
    elseif typing then
        ns:PlaceEditBox("header")
    else
        ns:PlaceEditBox(true)
    end
    local hide = min and not typing
    e:SetAlpha(hide and 0 or 1)
    if e.EnableMouse then e:EnableMouse(not hide) end
end

local ebHome -- { parent, points } of the edit box before docking
local function DockEditBox(on)
    local e = EditBox()
    if not e then return end
    if on then
        if not ebHome then
            ebHome = { parent = e:GetParent(), points = {} }
            for i = 1, Num(e:GetNumPoints(), 0) do ebHome.points[i] = { e:GetPoint(i) } end
        end
        e:SetParent(phone)
        ns.docked = true
        ns:PlaceEditBox(false)
    elseif ebHome then
        e:SetParent(ebHome.parent)
        e:ClearAllPoints()
        for _, p in ipairs(ebHome.points) do e:SetPoint(unpack(p)) end
        ebHome = nil
        ns.docked = false
    end
end

---------------------------------------------------------------------------
-- Replacing the game's chat: its windows (and any chat addon built on them)
-- are parked under a hidden frame; they keep working, just not visible.
---------------------------------------------------------------------------
local hider = CreateFrame("Frame")
hider:Hide()
local parked = {}
local CHAT_PARTS = { "GeneralDockManager", "ChatFrameMenuButton", "ChatFrameChannelButton", "QuickJoinToastButton",
    "ChatFrameToggleVoiceDeafenButton", "ChatFrameToggleVoiceMuteButton", "ChatAlertFrame" }

local function Park(f)
    if type(f) ~= "table" or parked[f] or not f.SetParent then return end
    parked[f] = f:GetParent() or UIParent
    f:SetParent(hider)
end

local function ParkAll()
    for i = 1, math.max(Num(NUM_CHAT_WINDOWS, 10), 20) do
        Park(_G["ChatFrame" .. i])
        Park(_G["ChatFrame" .. i .. "Tab"])
        Park(_G["ChatFrame" .. i .. "ButtonFrame"])
    end
    for _, n in ipairs(CHAT_PARTS) do Park(_G[n]) end
end

-- EllesmereUI Chat draws its own panels (on UIParent) over the game's chat
-- frames: while the phone replaces the chat, its visibility rule answers
-- "hidden" (optional, only when EllesmereUI Chat is loaded; its settings are
-- not touched).
local function EllesmereChatCfg()
    local db = _G._ECHAT_DB
    return type(db) == "table" and type(db.profile) == "table" and db.profile.chat or nil
end
local function EllesmereHide()
    local EUI = _G.EllesmereUI
    if type(EUI) ~= "table" or type(EUI.EvalVisibility) ~= "function" or not EllesmereChatCfg() then return end
    if not EUI._milkPhoneWrapped then
        local orig = EUI.EvalVisibility
        EUI.EvalVisibility = function(cfg, ...)
            if ns.replacing and cfg ~= nil and cfg == EllesmereChatCfg() then return false end
            return orig(cfg, ...)
        end
        EUI._milkPhoneWrapped = true
    end
    if type(EUI.RequestVisibilityUpdate) == "function" then pcall(EUI.RequestVisibilityUpdate) end
end
ns.EllesmereHide = EllesmereHide

local function ApplyReplace(on)
    if on then
        DockEditBox(true) -- before parking ChatFrame1 (its parent)
        ParkAll()
    else
        if ns.Combat then ns.Combat:Embed(false) end -- the game's combat log back home first
        for f, p in pairs(parked) do f:SetParent(p) end
        wipe(parked)
        DockEditBox(false)
    end
    ns.replacing = on and true or false
    pcall(EllesmereHide)
    -- the Combat chat open: the game's combat log goes in (it could not before)
    if on and ns.Combat and ns.Combat.view and ns.Combat.view:IsShown() then ns.Combat:Embed(true) end
end
ns.ApplyReplace = ApplyReplace

function ns:SetReplace(on)
    settings.replaceChat = on and true or false
    ApplyReplace(settings.replaceChat)
    if settings.replaceChat then settings.shown = true; phone:Show() end
    ns:Layout()
end

-- The game hid a message from addons (combat / encounter): only a banner.
-- The game's chat (and other chat addons) stays hidden while the phone is on:
-- the user does not want two chats, and reparenting the game's chat frames
-- in combat is best avoided.
function ns:Blocked(event)
    local inst = IsInInstance and select(2, IsInInstance()) or nil
    local n = (settings.secret and settings.secret.n or 0) + 1
    settings.secret = { n = n, t = time(), ev = event, combat = (InCombatLockdown and InCombatLockdown()) and true or false, instance = inst }
    if ns.blocked then return end
    ns.blocked = true
    banner:Show()
end

function ns:Unblock()
    if not ns.blocked then return end
    ns.blocked = false
    banner:Hide()
end

---------------------------------------------------------------------------
-- Fixed conversations (party / guild on top) and joined channels
---------------------------------------------------------------------------
-- Conversations switched off in the options (not stored, not listed).
local function HiddenKinds()
    -- npc: older separate NPC chat (NPCs now go to System); system: listed apart, at the end
    return { system = true, npc = true, combat = true, rolls = true }
end

-- System (+ NPCs): quiet unless monitored — no badge, no last message.
local function Quiet(c) return c and c.kind == "system" and not settings.monitorSystem end
ns.Quiet = Quiet
ns.HiddenKinds = HiddenKinds

local function TopKeys()
    local t = {}
    if IsInRaid and IsInRaid() then t[#t + 1] = "raid"
    elseif IsInGroup and IsInGroup() then t[#t + 1] = "party" end
    if IsInGuild and IsInGuild() then t[#t + 1] = "guild" end
    for _, k in ipairs(t) do Store:Ensure(k, k) end
    for _, x in ipairs(ns.Channels()) do
        if x.joined then t[#t + 1] = x.conv.key end
    end
    return t
end
ns.TopKeys = TopKeys

local function ChanKey(name) return "c:" .. name:lower() end

-- Channels used by other addons only to send data (no chat): hidden.
local ADDON_CHANNELS = { harvestmate = true, harvestmateb = true, harvestmatec = true }
function ns:ChannelHidden(name)
    local n = (name or ""):lower()
    return ADDON_CHANNELS[n] or (settings.hiddenChannels and settings.hiddenChannels[n]) or false
end

-- Channels the character is in (GetChannelList: id, name, disabled, ...),
-- then channel conversations with messages that are not joined now.
local function Channels()
    local t, seen = {}, {}
    local function add(id, name)
        if type(name) ~= "string" or name == "" or (tonumber(id) or 0) <= 0 then return end
        name = name:match("^(.-) %- ") or name
        if ns:ChannelHidden(name) then return end
        local c = Store:Ensure(ChanKey(name), "channel", name)
        c.chan = tonumber(id)
        if not seen[c.key] then seen[c.key] = true; t[#t + 1] = { conv = c, joined = true } end
    end
    -- GetChannelName(n) -> id, name: the same on every client version.
    if GetChannelName then
        for n = 1, 20 do
            local id, name = GetChannelName(n)
            add(id, name)
        end
    end
    if #t == 0 and GetChannelList then
        local list = { GetChannelList() }
        for i = 1, #list, 3 do add(list[i], list[i + 1]) end
    end
    local rest = {}
    for _, c in pairs(Store:Char().convs) do
        if c.kind == "channel" and not seen[c.key] and #c.msgs > 0 and not ns:ChannelHidden(c.name) then rest[#rest + 1] = { conv = c } end
    end
    table.sort(rest, function(a, b) return a.conv.key < b.conv.key end)
    for _, x in ipairs(rest) do t[#t + 1] = x end
    return t
end
ns.Channels = Channels

---------------------------------------------------------------------------
-- Auto-join General, Trade and LocalDefense (names are localized: the
-- server's own channel list is used, matched against known names)
---------------------------------------------------------------------------
local WANTED = {
    general = true, geral = true, allgemein = true, ["général"] = true,
    trade = true, ["comércio"] = true, comercio = true, handel = true, commerce = true,
    localdefense = true, defesalocal = true, defensalocal = true, lokaleverteidigung = true, ["défenselocale"] = true,
}
ns.WANTED = WANTED

local function Joined(name)
    if not GetChannelName then return false end
    local id = GetChannelName(name)
    return (tonumber(id) or 0) > 0
end

function ns:AutoJoin()
    if not settings.autoJoin or not JoinChannelByName then return end
    -- never touch channels in combat (the game may block the addon); retry after
    if InCombatLockdown and InCombatLockdown() then ns.joinAfterCombat = true return end
    ns.joinAfterCombat = nil
    -- not inside instances (General/Trade don't exist there; blocked channel calls
    -- can make the game offer to disable addons)
    if IsInInstance and IsInInstance() then return end
    if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
        local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
        if ok and locked then return end
    end
    local names = {}
    if EnumerateServerChannels then
        for _, n in ipairs({ EnumerateServerChannels() }) do
            if type(n) == "string" and WANTED[n:lower():gsub("%s", "")] then names[#names + 1] = n end
        end
    end
    if #names == 0 then names = { "General", "Trade", "LocalDefense" } end
    local done = {}
    for _, n in ipairs(names) do
        if not Joined(n) then
            local ok = pcall(JoinChannelByName, n)
            done[#done + 1] = n .. (ok and "" or "(error)")
        end
    end
    settings.lastJoin = { t = time(), tried = table.concat(names, ", "), joined = table.concat(done, ", ") }
    return done
end

---------------------------------------------------------------------------
-- List view
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- Copy: addons can't write to the clipboard, so the text opens selected in a
-- window and Ctrl+C copies it.
---------------------------------------------------------------------------
local function PlainText(t)
    return ((t or ""):gsub("|H.-|h(.-)|h", "%1"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        :gsub("|T.-|t", ""):gsub("|A.-|a", ""))
end

local function MsgLine(m)
    local who
    if not m.info then
        if IsMine(m) then who = Route.myName or (Store:Char() and Store:Char().me) or L.YOU else who = m.from end
    end
    local body = PlainText(m.text)
    if m.ev == "EMOTE" and m.from then body = m.from .. " " .. body end
    return "[" .. date("%d/%m %H:%M", m.t or 0) .. "] " .. (who and (who .. ": ") or "") .. body
end
ns.MsgLine = MsgLine

local copyFrame
function ns:ShowCopy(title, text)
    if not copyFrame then
        local f = CreateFrame("Frame", "MilkshaksonPhoneCopy", UIParent, "BackdropTemplate")
        f:SetSize(560, 380)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        if f.SetBackdrop then
            f:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
                insets = { left = 3, right = 3, top = 3, bottom = 3 } })
            f:SetBackdropColor(0.04, 0.08, 0.1, 0.96)
        end
        f:EnableMouse(true)
        f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        if UISpecialFrames then table.insert(UISpecialFrames, "MilkshaksonPhoneCopy") end
        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        f.title:SetPoint("TOPLEFT", 12, -10)
        local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", 0, 0)
        local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 12, -32)
        sf:SetPoint("BOTTOMRIGHT", -32, 12)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal or GameFontHighlight)
        eb:SetWidth(500)
        eb:SetScript("OnEscapePressed", function() f:Hide() end)
        eb:SetScript("OnTextChanged", function(self, user) if user then self:SetText(f.text or ""); self:HighlightText() end end)
        sf:SetScrollChild(eb)
        f.eb = eb
        copyFrame = f
    end
    copyFrame.text = text or ""
    copyFrame.title:SetText((title or "") .. "  -  " .. L.COPY_HINT)
    copyFrame.eb:SetText(copyFrame.text)
    copyFrame:Show()
    copyFrame.eb:SetFocus()
    copyFrame.eb:HighlightText()
end

function ns:CopyConv(key)
    local c = Store:Get(key)
    if not c then return end
    local lines = {}
    for _, m in ipairs(c.msgs) do lines[#lines + 1] = MsgLine(m) end
    ns:ShowCopy(Title(c), table.concat(lines, "\n"))
end

function ns:CopyMsg(m)
    if m then ns:ShowCopy(L.COPY_MSG, MsgLine(m)) end
end

local Archived -- (defined with the list, below)
local RenderList -- (defined below; list rows call it)

local function RowMenu(owner, c)
    if MenuUtil and MenuUtil.CreateContextMenu then
        MenuUtil.CreateContextMenu(owner, function(_, root)
            root:CreateTitle(Title(c))
            if c.kind == "whisper" and c.target then
                for _, a in ipairs(ns.ACTIONS) do
                    if a[1] ~= "WHISPER" and (not a[3] or a[3]()) then
                        root:CreateButton(L["ACT_" .. a[1]], function() Safe(a[2], c.target) end)
                    end
                end
                root:CreateDivider()
            end
            root:CreateButton(c.pinned and L.UNPIN or L.PIN, function() Store:SetPinned(c.key, not c.pinned) end)
            if c.kind == "whisper" or c.kind == "bn" then
                local a = Archived(c)
                root:CreateButton(a and L.UNARCHIVE or L.ARCHIVE, function()
                    c.archived = not a
                    ns:Refresh()
                end)
            end
            root:CreateButton(c.muted and L.UNMUTE or L.MUTE, function() Store:SetMuted(c.key, not c.muted) end)
            if c.kind == "channel" then
                root:CreateButton(L.HIDE_CHANNEL, function()
                    settings.hiddenChannels = settings.hiddenChannels or {}
                    settings.hiddenChannels[(c.name or ""):lower()] = true
                    if openKey == c.key then ns:CloseChat() end
                    ns:Refresh()
                end)
            end
            root:CreateButton(L.COPY_CONV, function() Safe(ns.CopyConv, ns, c.key) end)
            root:CreateButton(L.CLEAR_CONV, function() Store:ClearConv(c.key) end)
            root:CreateButton(L.DELETE_CONV, function() Safe(ns.DeleteConv, ns, c.key) end)
        end)
    else
        Store:SetMuted(c.key, not c.muted)
    end
end

-- Two letters for a chat in the collapsed list: first letters of the first two
-- words ("Trade - City" -> TC), or the first two of a single word ("Guild" -> Gu).
-- Joined words count as words: "LocalDefense" -> LD, "LookingForGroup" -> LF.
local function FirstChar(w) return w:match("^[%z\1-\127\194-\244][\128-\191]*") or "" end
local function Initials(c)
    local t = tostring(Title(c) or "")
    t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("^%s*%d+%.%s*", "")
    t = t:gsub("(%l)(%u)", "%1 %2")
    local words = {}
    for w in t:gmatch("[^%s%-%._/:,()%[%]]+") do words[#words + 1] = w end
    if #words == 0 then return "?" end
    if #words >= 2 then return (FirstChar(words[1]):upper() .. FirstChar(words[2]):upper()) end
    local a = FirstChar(words[1])
    local b = FirstChar(words[1]:sub(#a + 1))
    return a:upper() .. b
end
ns.Initials = Initials

local function Row(i)
    if rows[i] then return rows[i] end
    local r = CreateFrame("Button", nil, listContent)
    r:SetHeight(RowH())
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.sel = Tex(r, "BACKGROUND", COL.head)
    r.sel:SetAllPoints()
    r.sel:Hide()
    -- selected chat: a thin bar in the theme's accent at the left edge
    r.selBar = Tex(r, "ARTWORK", COL.accent)
    r.selBar:SetWidth(3)
    r.selBar:SetPoint("TOPLEFT", 0, -6)
    r.selBar:SetPoint("BOTTOMLEFT", 0, 6)
    r.selBar:Hide()
    local hl = r:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.05)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(32, 32)
    r.icon:SetPoint("LEFT", 8, 0)
    RoundIcon(r.icon)
    -- ring around the round icon (class color for players, the theme's color for the rest)
    r.ring = Tex(r, "ARTWORK", COL.ring, 0.9, -1)
    r.ring:SetSize(36, 36)
    r.ring:SetPoint("CENTER", r.icon, "CENTER")
    Round(r.ring)
    r.time = Font(r, "GameFontHighlightSmall", COL.sub, "RIGHT")
    r.time:SetPoint("TOPRIGHT", -8, -8)
    r.name = Font(r, "GameFontHighlight", COL.text)
    r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, -1)
    r.name:SetPoint("RIGHT", r.time, "LEFT", -4, 0)
    r.name:SetWordWrap(false)
    r.prev = Font(r, "GameFontHighlightSmall", COL.sub)
    r.prev:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 8, 2)
    r.prev:SetPoint("RIGHT", r, "RIGHT", -30, 0)
    r.prev:SetWordWrap(false)
    r.badge = CreateFrame("Frame", nil, r)
    r.badge:SetSize(18, 18)
    r.badge:SetPoint("BOTTOMRIGHT", -8, 6)
    local bg = Tex(r.badge, "ARTWORK", COL.accent)
    bg:SetAllPoints()
    Round(bg)
    r.badge.bg = bg
    r.badge.n = Font(r.badge, "GameFontHighlightSmall", { 0.05, 0.08, 0.1 }, "CENTER")
    r.badge.n:SetPoint("CENTER")
    -- collapsed list: initials on a dark strip at the bottom of the icon, full name on hover
    r.iniBg = r:CreateTexture(nil, "ARTWORK", nil, 7)
    r.iniBg:SetColorTexture(0, 0, 0, 0.7)
    r.iniBg:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMLEFT")
    r.iniBg:SetPoint("BOTTOMRIGHT", r.icon, "BOTTOMRIGHT")
    r.iniBg:SetHeight(13)
    if r.icon.roundMask and r.iniBg.AddMaskTexture then pcall(r.iniBg.AddMaskTexture, r.iniBg, r.icon.roundMask) end
    r.iniBg:Hide()
    r.ini = Font(r, "GameFontHighlightSmall", COL.text, "CENTER")
    r.ini:SetPoint("BOTTOM", r.icon, "BOTTOM", 0, 1)
    r.ini:Hide()
    r:SetScript("OnEnter", function(self)
        if not (settings.listCollapsed and self.conv) then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(Title(self.conv))
        local pv = self.prev:GetText()
        if pv and pv ~= "" then GameTooltip:AddLine(pv, 0.7, 0.7, 0.7, true) end
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", GameTooltip_Hide)
    local line = Tex(r, "BORDER", COL.sep, 0.6)
    line:SetHeight(1)
    line:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 8, -6)
    line:SetPoint("BOTTOMRIGHT", r, "BOTTOMRIGHT", 0, 0)
    r:SetScript("OnClick", function(self, btn)
        local c = self.conv
        if c.kind == "archive" or c.kind == "back" then
            ns.listMode = c.kind == "archive" and "archived" or "main"
            listScroll:SetVerticalScroll(0)
            RenderList()
            return
        end
        if btn == "RightButton" then RowMenu(self, c) else ns:Open(c.key) end
    end)
    rows[i] = r
    return r
end

-- The scroll child does not follow the scroll frame's width by itself, and the
-- frame can still be 0 wide before the first layout: fall back to the phone size.
local function FitWidth(scroll, content, fallback)
    local w = Num(scroll:GetWidth(), 0)
    if w <= 1 then w = fallback end
    content:SetWidth(w)
    return w
end

-- Archived: private chats with nothing new for settings.archiveDays (0 = never),
-- or archived by hand (c.archived true; false = kept out by hand). A new message
-- brings a chat back (c.archived cleared when it arrives).
Archived = function(c)
    if c.kind ~= "whisper" and c.kind ~= "bn" then return false end
    if c.archived ~= nil then return c.archived end
    local days = tonumber(settings.archiveDays) or 3
    if days <= 0 or c.pinned or (c.last or 0) <= 0 then return false end
    return time() - c.last > days * 86400
end
ns.Archived = Archived
ns.listMode = "main"

RenderList = function()
    FitWidth(listScroll, listContent, ListW())
    local col = settings.listCollapsed
    local list = {}
    local arch = { key = "@archive", kind = "archive", msgs = {}, unread = 0, n = 0 }
    local inArchive = ns.listMode == "archived"
    local q = ns.query
    if q then
        -- search: every chat whose name matches or that has matching messages
        local found = {}
        for _, c in pairs(Store:Char().convs) do
            if c.kind ~= "npc" and not (c.kind == "channel" and ns:ChannelHidden(c.name)) then
                local n, lastM = 0, nil
                for _, m in ipairs(c.msgs) do if Matches(m, q) then n = n + 1; lastM = m end end
                local nameHit = (Title(c) or ""):lower():find(q, 1, true)
                if n > 0 or nameHit then
                    c.hits, c.hitMsg = n, lastM
                    found[#found + 1] = c
                end
            end
        end
        table.sort(found, function(a, b)
            local ta, tb = a.hitMsg and a.hitMsg.t or 0, b.hitMsg and b.hitMsg.t or 0
            if ta ~= tb then return ta > tb end
            return a.key < b.key
        end)
        list = found
        inArchive = true -- (no folders / combat / system rows while searching)
    end
    if inArchive and not q then list[1] = { key = "@back", kind = "back", msgs = {}, unread = 0 } end
    for _, c in ipairs(q and {} or Store:List(TopKeys(), HiddenKinds())) do
        if not (c.kind == "channel" and ns:ChannelHidden(c.name)) then
            local a = Archived(c)
            if inArchive then
                if a then list[#list + 1] = c end
            elseif a then
                arch.n = arch.n + 1
                if not c.muted then arch.unread = arch.unread + (c.unread or 0) end
            else
                list[#list + 1] = c
            end
        end
    end
    if not inArchive then
        -- private chats with nothing new for a few hours go down, after the
        -- channels (Trade...): the fresh ones stay on top
        local hours = tonumber(settings.staleHours) or 2
        if hours > 0 then
            local fresh, stale, lastChan = {}, {}, 0
            local now = time()
            for _, c in ipairs(list) do
                if (c.kind == "whisper" or c.kind == "bn") and not c.pinned and (c.unread or 0) == 0
                    and now - (c.last or 0) > hours * 3600 then
                    stale[#stale + 1] = c
                else
                    fresh[#fresh + 1] = c
                    -- after the last channel and after the fresh private chats
                    -- (joined channels are listed on top, before all private chats)
                    if c.kind == "channel" or c.kind == "whisper" or c.kind == "bn" then lastChan = #fresh end
                end
            end
            if #stale > 0 then
                local at = (lastChan > 0) and lastChan or #fresh
                for i, c in ipairs(stale) do table.insert(fresh, at + i, c) end
                list = fresh
            end
        end
    end
    if inArchive then
        -- (only the archived chats)
    elseif arch.n > 0 then
        list[#list + 1] = arch
    end
    if not inArchive and settings.showRolls then -- loot rolls: who chose Need / Greed / Pass and who won
        local rc = Store:Ensure("rolls", "rolls")
        local inst = IsInInstance and select(2, IsInInstance()) or nil
        if inst == "party" or inst == "raid" or inst == "scenario" then
            -- in a dungeon / raid: right under the group chats
            local at = 0
            for i, c in ipairs(list) do
                if c.key == "party" or c.key == "raid" or c.key == "instance" then at = i end
            end
            table.insert(list, at + 1, rc)
        else
            list[#list + 1] = rc
        end
    end
    if inArchive then
    elseif settings.combatLog then -- combat summary + the game's combat log
        list[#list + 1] = Store:Ensure("combat", "combat")
    end
    if not inArchive and (settings.showSystem or settings.showNPC) then -- always last
        list[#list + 1] = Store:Ensure("system", "system")
    end
    ns.shownList = list
    for i, c in ipairs(list) do
        local r = Row(i)
        r.conv = c
        r:ClearAllPoints()
        r:SetHeight(RowH())
        r:SetPoint("TOPLEFT", listContent, "TOPLEFT", 0, -(i - 1) * RowH())
        r:SetPoint("RIGHT", listContent, "RIGHT")
        SetIcon(r.icon, c)
        r.icon:ClearAllPoints()
        r.icon:SetPoint("LEFT", col and math.floor((COLL_W - 32) / 2) or 8, 0)
        r.name:SetShown(not col)
        r.prev:SetShown(not col)
        r.time:SetShown(not col)
        r.ini:SetShown(col and true or false)
        r.iniBg:SetShown(col and true or false)
        if col then r.ini:SetText(Initials(c)) end
        r.badge:ClearAllPoints()
        if col then r.badge:SetPoint("CENTER", r.icon, "TOPRIGHT", -1, -1) else r.badge:SetPoint("BOTTOMRIGHT", -8, 6) end
        r.name:SetText(Title(c))
        local cc = NameColor(c)
        r.name:SetTextColor(cc[1], cc[2], cc[3])
        local m = c.msgs[#c.msgs]
        if q then m = c.hitMsg end
        local quiet = not q and (Quiet(c) or c.kind == "combat" or c.kind == "archive" or c.kind == "back")
        if quiet then m = nil end
        r.time:SetText(m and ListTime(m.t) or "")
        local special = (c.kind == "combat" and ns.Combat:Preview()) or (c.kind == "archive" and L.ARCHIVED_SUB)
            or (c.kind == "back" and "")
        r.prev:SetText(m and ((q and c.hits and c.hits > 1) and ("(" .. c.hits .. ") ") or "") .. Preview(c, m)
            or special or (q and L.SEARCH_NAME) or (quiet and L.QUIET or L.NO_MSGS))
        local pc = TypeColor(m, c) or COL.sub
        r.prev:SetTextColor(pc[1], pc[2], pc[3])
        local n = (c.kind == "archive" and c.unread) or (quiet and 0) or (c.muted and (c.unseen or 0) or (c.unread or 0))
        r.sel:SetShown(openKey == c.key)
        r.selBar:SetShown(openKey == c.key)
        local rc = (c.kind == "whisper" and ClassColor(c.cls)) or COL.ring
        r.ring:SetColorTexture(rc[1], rc[2], rc[3], 0.9)
        if n > 0 then
            r.badge.n:SetText(n > 99 and "99+" or tostring(n))
            local bc = c.muted and COL.sub or COL.accent
            r.badge.bg:SetColorTexture(bc[1], bc[2], bc[3], 1)
            r.badge:Show()
            r.time:SetTextColor(bc[1], bc[2], bc[3])
        else
            r.badge:Hide()
            r.time:SetTextColor(COL.sub[1], COL.sub[2], COL.sub[3])
        end
        r:Show()
    end
    for i = #list + 1, #rows do rows[i]:Hide() end
    listContent:SetHeight(math.max(1, #list * RowH()))
    emptyText:SetText(q and L.SEARCH_NONE or L.EMPTY)
    emptyText:SetShown(#list == 0 and not col)
    return #list
end

---------------------------------------------------------------------------
-- Conversation view
---------------------------------------------------------------------------
-- Sender name as the game's player link: |Hplayer:Name-Realm:lineID|h Name |h
local function PlayerLink(m)
    if IsMine(m) or not m.from or m.npc then return m.from or "" end
    return "|Hplayer:" .. (m.full or m.from) .. (m.line and (":" .. m.line) or "") .. "|h" .. m.from .. "|h"
end
ns.PlayerLink = PlayerLink

-- Opens (or creates) the private chat with a player and starts typing to them.
function ns:Whisper(full)
    if not full or full == "" then return end
    local short = full:gsub("%-.*$", "")
    if Ambiguate then short = Ambiguate(full, "short") end
    local c = Store:Ensure("w:" .. full:lower(), "whisper", short)
    c.target = full
    ns:Open(c.key)
    ns:Compose()
end

-- The game's own player menu (UnitPopup) is NOT opened from the phone: opening
-- it from addon code taints the game's menu state, and the next ESC then tries
-- SpellStopCasting tainted -> "AddOn 'Milkshakson-Phone' tried to call the
-- protected function" and the game offers to disable addons (seen in dungeons,
-- 2026-11-24). The phone's own menu has the actions instead.

-- Calls a game function; a failure is shown on the phone (never silent).
local function Call(f, ...)
    if type(f) ~= "function" then ShowError("function not available in this client") return end
    local ok, err = pcall(f, ...)
    if not ok then ShowError(err) end
end

-- /who on a player: the answer is shown on the phone (System may be off and
-- the game's chat hidden). Results come by WHO_LIST_UPDATE (to the Who list)
-- or as a system line; both are watched for a few seconds.
local whoWait
function ns:Who(full)
    whoWait = { name = (full:gsub("%-.*$", "")):lower(), t = GetTime() }
    local FL = C_FriendList
    if FL and FL.SetWhoToUi then pcall(FL.SetWhoToUi, true) end
    local q = 'n-"' .. full:gsub("%-.*$", "") .. '"'
    if FL and FL.SendWho then
        local origin = Enum and Enum.SocialWhoOrigin and Enum.SocialWhoOrigin.Chat
        Call(FL.SendWho, q, origin)
    else
        Call(SendWho, q)
    end
end

function ns:WhoResult()
    if not whoWait or GetTime() - whoWait.t > 10 then return end
    local FL = C_FriendList
    if not (FL and FL.GetNumWhoResults and FL.GetWhoInfo) then return end
    local n = FL.GetNumWhoResults() or 0
    local lines = {}
    for i = 1, n do
        local w = FL.GetWhoInfo(i)
        if type(w) == "table" and w.fullName then
            lines[#lines + 1] = L.WHO_LINE:format(w.fullName, w.level or 0, w.raceStr or "", w.classStr or "",
                w.area or "", (w.fullGuildName and w.fullGuildName ~= "") and ("<" .. w.fullGuildName .. ">") or "")
        end
    end
    whoWait = nil
    Notice(L.ACT_WHO, #lines > 0 and table.concat(lines, "\n") or L.WHO_NONE)
end

-- The system line of a /who sent to the chat ("Name: Level 20 ..."), if any.
function ns:WhoSystem(text)
    if not whoWait or GetTime() - whoWait.t > 10 or type(text) ~= "string" then return end
    if text:lower():find(whoWait.name, 1, true) then
        whoWait = nil
        Notice(L.ACT_WHO, text)
    end
end

ns.ACTIONS = {
    { "WHISPER", function(n) ns:Whisper(n) end },
    { "INVITE", function(n) Call((C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit, n) end },
    { "GUILD_INVITE", function(n) Call((C_GuildInfo and C_GuildInfo.Invite) or GuildInvite, n) end,
        function() return IsInGuild and IsInGuild() and (not CanGuildInvite or CanGuildInvite()) end },
    { "ADD_FRIEND", function(n) Call((C_FriendList and C_FriendList.AddFriend) or AddFriend, n) end },
    { "WHO", function(n) ns:Who(n) end },
    { "COPY_NAME", function(n) if MilkshaksonUI then MilkshaksonUI:CopyLink(n, n) end end },
    { "IGNORE", function(n) Call((C_FriendList and C_FriendList.AddIgnore) or AddIgnore, n) end },
}

-- Right-click on a player (bubble, name or private chat): the actions of the
-- game's chat menu, plus the game's own menu at the end.
function ns:PlayerMenu(owner, full, line, chatType, msg)
    if not full or full == "" then return end
    local short = (Ambiguate and Ambiguate(full, "short")) or full:gsub("%-.*$", "")
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        ns:Whisper(full)
        return
    end
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle(short)
        for _, a in ipairs(ns.ACTIONS) do
            if not a[3] or a[3]() then
                root:CreateButton(L["ACT_" .. a[1]], function() Safe(a[2], full) end)
            end
        end
        if msg then
            root:CreateDivider()
            root:CreateButton(L.COPY_MSG, function() Safe(ns.CopyMsg, ns, msg) end)
        end
    end)
end

-- Click on a link in a bubble. Player name: left = private chat on the phone,
-- right = the phone's player menu, with modifiers = nothing (no game player menu).
function ns:OnLink(link, text, button)
    local kind, rest = (link or ""):match("^(%a+):(.*)$")
    if kind == "player" then
        local name, line = rest:match("^([^:]+):?(%d*)")
        local mod = (IsShiftKeyDown and IsShiftKeyDown()) or (IsControlKeyDown and IsControlKeyDown()) or (IsAltKeyDown and IsAltKeyDown())
        if button == "RightButton" then
            ns:PlayerMenu(ns.linkOwner, name, tonumber(line))
            return
        end
        if button == "LeftButton" and not mod then
            ns:Whisper(name)
            return
        end
        -- shift / ctrl / alt: nothing from the game's player link (it opens the
        -- game's player menu from addon code, which taints ESC)
        return
    end
    if kind == "BNplayer" then return end
    if SetItemRef then SetItemRef(link, text, button, ChatFrame1) end
end

local function Bubble(i)
    if bubbles[i] then return bubbles[i] end
    local b = CreateFrame("Frame", nil, chatContent)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.name = Font(b, "GameFontNormalSmall", nil, nil, "chat")
    b.name:SetPoint("TOPLEFT", 8, -5)
    b.text = Font(b, "GameFontHighlight", COL.text, nil, "chat")
    b.time = Font(b, "GameFontHighlightSmall", COL.sub, "RIGHT", "chat")
    b.time:SetPoint("BOTTOMRIGHT", -7, 4)
    b:EnableMouse(true)
    if b.SetHyperlinksEnabled then
        b:SetHyperlinksEnabled(true)
        b:SetScript("OnHyperlinkClick", function(self, link, text, button)
            ns.linkOwner = self
            Safe(ns.OnLink, ns, link, text, button)
        end)
    end
    -- right-click anywhere on a message from another player: player menu
    b:SetScript("OnMouseUp", function(self, button)
        local m = self.msg
        local who = m and not IsMine(m) and not m.info and not m.npc and (m.full or m.from) -- older messages have no full name
        settings.lastClick = { button = tostring(button), who = who or "-", menu = (MenuUtil and MenuUtil.CreateContextMenu) and "yes" or "no" }
        if button == "RightButton" and who then
            Safe(ns.PlayerMenu, ns, self, who, m.line, m.ev, m)
        elseif button == "RightButton" and m then
            -- mine / system / NPC: just copy
            if MenuUtil and MenuUtil.CreateContextMenu then
                MenuUtil.CreateContextMenu(self, function(_, root)
                    root:CreateButton(L.COPY_MSG, function() Safe(ns.CopyMsg, ns, m) end)
                    root:CreateButton(L.COPY_CONV, function() Safe(ns.CopyConv, ns, openKey) end)
                end)
            else
                Safe(ns.CopyMsg, ns, m)
            end
        end
    end)
    -- hover: shows the message is clickable
    b.hl = b:CreateTexture(nil, "HIGHLIGHT")
    b.hl:SetAllPoints()
    b.hl:SetColorTexture(1, 1, 1, 0.06)
    bubbles[i] = b
    return b
end

local function Sep(i)
    if seps[i] then return seps[i] end
    local s = CreateFrame("Frame", nil, chatContent)
    Tex(s, "BACKGROUND", COL.info):SetAllPoints()
    s.text = Font(s, "GameFontHighlightSmall", COL.sub, "CENTER", "chat")
    s.text:SetPoint("CENTER")
    seps[i] = s
    return s
end

local function ScrollBottom()
    local function go()
        if chatScroll.UpdateScrollChildRect then chatScroll:UpdateScrollChildRect() end
        local r = chatScroll:GetVerticalScrollRange()
        if type(r) == "number" then chatScroll:SetVerticalScroll(r) end
        if ns.chatBar then ns.chatBar.Sync() end
    end
    go()
    if C_Timer and C_Timer.After then C_Timer.After(0, go) end
end

local function AtBottom()
    local r, v = chatScroll:GetVerticalScrollRange(), chatScroll:GetVerticalScroll()
    if type(r) ~= "number" or type(v) ~= "number" then return true end
    return r - v < 30
end

-- What is drawn now, so a new message only adds its own bubble.
local view = { show = PAGE }

local function ResetView(key, width)
    for _, b in ipairs(bubbles) do b:Hide() end
    for _, x in ipairs(seps) do x:Hide() end
    view.key, view.width, view.y, view.nb, view.nsep, view.lastDay, view.last, view.count, view.first =
        key, width, 8, 0, 0, nil, nil, 0, nil
end

local function PlaceMsg(c, m, maxW, group)
    local day = Today(m.t)
    if day ~= view.lastDay then
        view.lastDay = day
        view.nsep = view.nsep + 1
        local x = Sep(view.nsep)
        x.text:SetText(DayLabel(m.t))
        x:SetSize(Num(x.text:GetUnboundedStringWidth(), 60) + 18, 18)
        x:ClearAllPoints()
        x:SetPoint("TOP", chatContent, "TOP", 0, -view.y)
        x:Show()
        view.y = view.y + 26
    end
    view.nb = view.nb + 1
    local b = Bubble(view.nb)
    local tc = TypeColor(m, c)
    b.text:ClearAllPoints()
    b.text:SetWidth(maxW)
    b.text:SetText(Highlight(Body(m, openKey and (Store:Get(openKey) or {}).kind), ns.query))
    local tw = math.min(maxW, Num(b.text:GetUnboundedStringWidth(), maxW))
    local w, h
    b:ClearAllPoints()
    if m.info then
        local t = COL.info
        b.bg:SetColorTexture(t[1], t[2], t[3], 1)
        local fc = tc or COL.sub
        b.text:SetTextColor(fc[1], fc[2], fc[3])
        b.text:SetJustifyH("CENTER")
        b.name:Hide()
        b.time:Hide()
        b.text:SetWidth(tw + 2)
        b.text:SetPoint("TOPLEFT", 8, -5)
        w, h = tw + 18, Num(b.text:GetStringHeight(), 14) + 10
        b:SetPoint("TOP", chatContent, "TOP", 0, -view.y)
    else
        local mine = IsMine(m)
        local t = mine and COL.outB or COL.inB
        b.bg:SetColorTexture(t[1], t[2], t[3], 1)
        local fc = tc or COL.text
        b.text:SetTextColor(fc[1], fc[2], fc[3])
        b.text:SetJustifyH("LEFT")
        local showName = group and not mine and m.from
        local nw = 0
        if showName then
            local nc = ClassColor(m.cls) or COL.accent
            b.name:SetText(PlayerLink(m) .. (m.tag == "leader" and (" (" .. L.LEADER .. ")") or ""))
            b.name:SetTextColor(nc[1], nc[2], nc[3])
            b.name:Show()
            nw = Num(b.name:GetUnboundedStringWidth(), 0)
        else
            b.name:Hide()
        end
        b.time:SetText(Clock(m.t))
        b.time:Show()
        local inner = math.max(tw, math.min(nw, maxW), Num(b.time:GetUnboundedStringWidth(), 30))
        -- alignment option: "messenger" (yours right), "left" (all left), "right" (all right)
        local align = settings.align or "messenger"
        local right = (align == "right") or (align == "messenger" and mine)
        -- bubbles take the whole width (edges line up), unless "fit to text" is on
        if not settings.fitBubbles then
            inner = maxW
            b.text:SetJustifyH(right and "RIGHT" or "LEFT")
        end
        b.text:SetWidth(inner + 2)
        local top = showName and 19 or 6
        b.text:SetPoint("TOPLEFT", 8, -top)
        w, h = inner + 18, top + Num(b.text:GetStringHeight(), 14) + 17
        if right then
            b:SetPoint("TOPRIGHT", chatContent, "TOPRIGHT", -8, -view.y)
        else
            b:SetPoint("TOPLEFT", chatContent, "TOPLEFT", 8, -view.y)
        end
    end
    b.msg = m
    b:SetSize(w, h)
    b:Show()
    view.y = view.y + h + 5
    view.count = view.count + 1
end

-- mode: "open" (full, scroll to the end), "more" (full, keep the place),
-- nil (only add what is new; full when the size changed or it grew too much).
local function RenderChat(mode)
    local c = Store:Get(openKey)
    if not c then
        ResetView(nil, 0)
        chatTitle:SetText(L.PICK)
        chatTitle:SetTextColor(COL.sub[1], COL.sub[2], COL.sub[3])
        chatSub:SetText("")
        SetIcon(chatIcon, { kind = "channel" })
        chatRing:SetColorTexture(COL.ring[1], COL.ring[2], COL.ring[3], 0.9)
        return 0
    end
    chatTitle:SetText(Title(c))
    local cc = NameColor(c)
    chatTitle:SetTextColor(cc[1], cc[2], cc[3])
    chatSub:SetText(Sub(c))
    SetIcon(chatIcon, c)
    local rc = (c.kind == "whisper" and ClassColor(c.cls)) or COL.ring
    chatRing:SetColorTexture(rc[1], rc[2], rc[3], 0.9)

    local width = FitWidth(chatScroll, chatContent, Num(phone:GetWidth(), settings.w) - ListW())
    -- long messages use the whole width (8 px margin each side + 8 px padding inside), so edges line up
    local maxW = math.floor(width) - 16 - 18
    local msgs = c.msgs
    local q = ns.query
    if q then
        local t = {}
        for _, m in ipairs(c.msgs) do if Matches(m, q) then t[#t + 1] = m end end
        msgs = t
    end
    if view.query ~= q then mode = mode or "open" end -- search changed: draw it all again
    local stick = mode == "open" or (mode == nil and AtBottom())
    local from
    if mode == nil and view.key == c.key and view.width == width then
        if view.last == nil and #msgs == 0 then return view.count end
        for i = #msgs, 1, -1 do
            if msgs[i] == view.last then from = i + 1 break end
        end
        if from and view.count + (#msgs - from + 1) > view.show + PAGE then from = nil end
    end
    if not from then
        ResetView(c.key, width)
        view.query = q
        from = math.max(1, #msgs - view.show + 1)
        view.first = from
    end
    local group = IsGroup(c.kind)
    for i = from, #msgs do PlaceMsg(c, msgs[i], maxW, group) end
    view.last = msgs[#msgs]
    chatContent:SetHeight(view.y + 4)
    if stick then ScrollBottom() end
    return view.count
end
ns.View = view

-- Scrolled to the top: draw an older page, keeping the same message on screen.
function ns:More()
    local c = Store:Get(openKey)
    if not c or not view.first or view.first <= 1 then return end
    local oldH, oldV = view.y, Num(chatScroll:GetVerticalScroll(), 0)
    view.show = view.show + PAGE
    RenderChat("more")
    if chatScroll.UpdateScrollChildRect then chatScroll:UpdateScrollChildRect() end
    chatScroll:SetVerticalScroll(oldV + (view.y - oldH))
end

---------------------------------------------------------------------------
-- Height transition (minimize / restore): eased, content fades in
---------------------------------------------------------------------------
local anim = CreateFrame("Frame", nil, UIParent)
anim:Hide()
local function Fade(a)
    for _, f in ipairs({ listScroll, chatView, inputBar }) do if f then f:SetAlpha(a) end end
end
local function Finish(self)
    self:Hide()
    local done = self.done
    self.done = nil
    Fade(1)
    if done then done() end
end
anim:SetScript("OnUpdate", function(self, elapsed)
    self.t = self.t + elapsed
    local p = math.min(1, self.t / self.dur)
    local e = p * p * (3 - 2 * p) -- smoothstep
    phone:SetHeight(self.from + (self.to - self.from) * e)
    if self.mode == "in" then Fade(e) elseif self.mode == "out" then Fade(1 - e) end
    if p >= 1 then Safe(Finish, self) end
end)

-- mode "in": content fades in; "out": fades out, then done() hides it.
function ns:AnimateHeight(target, mode, done)
    local cur = Num(phone:GetHeight(), target)
    local dur = tonumber(settings.animTime) or 0.25
    if not settings.animate or dur <= 0 or math.abs(cur - target) < 1 or not phone:IsShown() then
        anim:Hide()
        anim.done = nil
        phone:SetHeight(target)
        Fade(1)
        if done then done() end
        return
    end
    if anim:IsShown() and anim.to == target then return end -- already going there
    anim.from, anim.to, anim.t, anim.mode, anim.dur, anim.done = cur, target, 0, mode, dur, done
    if mode == "in" then Fade(0) end
    anim:Show()
end

---------------------------------------------------------------------------
-- Layout / refresh
---------------------------------------------------------------------------
function ns:Layout()
    if not phone then return end
    local min = settings.min and not ns.peek -- peek: minimized, opened by the mouse
    local inChat = openKey ~= nil and not min
    UpdateMinButtons(min)
    -- Minimized: the game's typing box (always shown with some chat styles) would sit
    -- over the header and take the mouse from the pills: invisible and click-through.
    ns:SyncEditBox(min)
    -- Two panes, like a desktop messenger: chats on the left, the open chat on the right.
    local function Panes(m)
        listView:ClearAllPoints()
        listView:SetPoint("TOPLEFT", phone, "TOPLEFT", 0, -STATUS_H - TOP_H - (m and 0 or SEARCH_H))
        ns:PlaceProfBar(m)
        if searchRow then searchRow:SetShown(not m) end
        if m then
            listView:SetPoint("BOTTOMRIGHT", phone, "BOTTOMRIGHT")
        else
            listView:SetPoint("BOTTOMLEFT", phone, "BOTTOMLEFT", 0, INPUT_H + 10)
            if not ns.listAnimating then listView:SetWidth(ListW()) end
        end
        listView:Show()
        listScroll:SetShown(not m)
        -- top bar: "Chats" + pills when minimized; drawer arrow + search when open
        local col = settings.listCollapsed and not m
        listTitle:SetShown(m and true or false)
        if ns.miniRow then ns.miniRow:SetShown(m and true or false) end
        if searchBox then searchBox:SetShown(not m) end
        local hb = ns.headButtons
        if hb then
            hb.drawer:SetShown(not m)
            ns:DrawerIcon(col)
        end
        chatView:SetShown(not m and openKey ~= "combat")
        if not m and openKey == "combat" then ns.Combat:Show() else ns.Combat:Hide() end
        inputBar:SetShown(not m)
        grip:SetShown(not m and not settings.locked)
        for _, z in ipairs(ns.sizers or {}) do z:SetShown(not m and not settings.locked) end
    end
    if min then
        -- minimizing: the content fades out while the height goes down, then it is hidden
        ns:AnimateHeight(MiniH(), "out", function() Panes(true) end)
    else
        Panes(false)
        ns:AnimateHeight(settings.h, "in")
    end
    local c = Store:Get(openKey)
    if inChat and c and ChatTarget(c) then
        inputText:SetText(L.INPUT_TO:format(Title(c)))
    elseif inChat then
        inputText:SetText(L.INPUT_READONLY)
    else
        inputText:SetText(L.INPUT_NONE)
    end
end

-- Minimized: colored count pills for guild, party / raid and whispers.
local pills = {}

-- The game's own color for a chat type (whatever the text color option says).
local function GameColor(ev)
    local info = ChatTypeInfo and ChatTypeInfo[ev]
    if info and info.r then return { info.r, info.g, info.b } end
    return TYPE_COL[ev] or COL.accent
end

-- { id, label, color, count, key = chat to open } for what has unread messages.
function ns:MiniCounts()
    local convs = Store:Char().convs
    local out = {}
    local g = convs.guild
    if g and not g.muted and (g.unread or 0) > 0 then
        out[#out + 1] = { id = "guild", label = L.K_guild, ev = "GUILD", n = g.unread, key = "guild" }
    end
    local best, n, ev, label = nil, 0, "PARTY", L.K_party
    for _, k in ipairs({ "party", "raid", "instance" }) do
        local c = convs[k]
        if c and not c.muted and (c.unread or 0) > 0 then
            n = n + c.unread
            if not best or (c.last or 0) > (convs[best].last or 0) then best = k end
        end
    end
    if best == "raid" then ev, label = "RAID", L.K_raid elseif best == "instance" then ev, label = "INSTANCE_CHAT", L.K_instance end
    if n > 0 then out[#out + 1] = { id = "party", label = label, ev = ev, n = n, key = best } end
    local wn, wkey, wlast = 0, nil, -1
    for key, c in pairs(convs) do
        if (c.kind == "whisper" or c.kind == "bn") and not c.muted and (c.unread or 0) > 0 then
            wn = wn + c.unread
            if (c.last or 0) > wlast then wkey, wlast = key, c.last or 0 end
        end
    end
    if wn > 0 then out[#out + 1] = { id = "whisper", label = L.WHISPERS, ev = "WHISPER", n = wn, key = wkey } end
    local sk = convs.skills
    if sk and not sk.muted and (sk.unread or 0) > 0 then
        out[#out + 1] = { id = "skills", label = L.K_skills, ev = "SKILL", n = sk.unread, key = "skills" }
    end
    local ah = convs.auction
    if ah and not ah.muted and (ah.unread or 0) > 0 then
        out[#out + 1] = { id = "auction", label = L.K_auction, ev = "SYSTEM", n = ah.unread, key = "auction" }
    end
    return out
end

local function Pill(i)
    if pills[i] then return pills[i] end
    local b = CreateFrame("Button", nil, listHead)
    b:SetHeight(MINI_ROW - 12)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.text = Font(b, "GameFontHighlightSmall", { 0.05, 0.08, 0.1 }, "CENTER")
    b.text:SetPoint("CENTER")
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.15)
    b:SetScript("OnClick", function(self) if self.key then ns:Open(self.key) end end)
    -- mouse over a pill (option): open the phone on that chat until the mouse leaves
    b:SetScript("OnEnter", function(self)
        if self.key and settings.hoverExpand and not ns.holdPeek then Safe(ns.Peek, ns, self.key) end
    end)
    pills[i] = b
    return b
end

-- Top bar, open or minimized: professions on the left, the buttons on the right.
-- Minimized, "Chats (n)" and the unread pills get the row under it. Every row
-- centers its items vertically.
function ns:PlaceProfBar(m)
    if not profBar then return end
    if m == nil then m = settings.min and not ns.peek end
    local cfg = ns.headButtons and ns.headButtons.cfg
    profBar:ClearAllPoints()
    profBar:SetPoint("TOPLEFT", listHead, "TOPLEFT")
    profBar:SetPoint("BOTTOMLEFT", listHead, "BOTTOMLEFT")
    if cfg then profBar:SetPoint("RIGHT", cfg, "LEFT", -6, 0) end
    profBar:Show()
    listTitle:ClearAllPoints()
    listTitle:SetPoint("LEFT", listHead, "BOTTOMLEFT", 12, -math.floor(MINI_ROW / 2))
end

-- Minimized and not moving: follow the rows (professions, pills) in the height.
local function FitMini()
    if not (phone and settings.min and not ns.peek) then return end
    if anim and anim:IsShown() then
        if anim.to ~= MiniH() then anim.to = MiniH() end
        return
    end
    phone:SetHeight(MiniH())
end
ns.FitMini = FitMini

local function UpdatePills()
    local list = (settings.min and not ns.peek) and ns:MiniCounts() or {}
    local prev
    for i, x in ipairs(list) do
        local b = Pill(i)
        local c = GameColor(x.ev)
        b.bg:SetColorTexture(c[1], c[2], c[3], 1)
        b.text:SetText(x.label .. "  " .. (x.n > 99 and "99+" or x.n))
        b:SetWidth(Num(b.text:GetUnboundedStringWidth(), 60) + 20)
        b.key = x.key
        b:ClearAllPoints()
        -- second row, after "Chats (n)", centered on it
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 8, 0)
        else b:SetPoint("LEFT", listTitle, "RIGHT", 14, 0) end
        b:Show()
        prev = b
    end
    for i = #list + 1, #pills do pills[i]:Hide() end
    if ns.pillCount ~= #list then
        ns.pillCount = #list
        FitMini()
    end
    return #list
end
ns.UpdatePills = UpdatePills

local function UpdateTitle()
    local n = Store:Unread({ npc = true, system = not settings.monitorSystem or nil })
    listTitle:SetText(n > 0 and L.CHATS_N:format(n) or L.CHATS)
    UpdatePills()
end

local pending
local function DoRefresh(_, key)
    if not phone then return end
    UpdateTitle()
    if not phone:IsShown() or (settings.min and not ns.peek) then return end -- drawn when shown again
    RenderList()
    if openKey and (key == nil or key == openKey) then
        if not Store:Get(openKey) then ns:CloseChat() else RenderChat() end
    end
end

local function Later()
    if pending then return end
    pending = true
    local function run() pending = false; ns:Refresh() end
    if C_Timer and C_Timer.After then C_Timer.After(0.25, run) else run() end
end

-- Opens the phone on a chat while it stays minimized (mouse over a pill).
function ns:Peek(key)
    if not (settings.min and not ns.peek) then return end
    ns.peek = true
    openKey = key
    Store:Read(key)
    local c = Store:Get(key)
    if c then ns:SetSticky(c) end
    ns:Layout()
    RenderChat("open")
    UpdateTitle()
    RenderList()
end

local function DoOpen(_, key)
    openKey = key
    settings.lastOpen = key
    settings.min = false
    ns.peek = false -- a click on a chat restores the phone for good
    Store:Read(key)
    local c = Store:Get(key)
    if c then ns:SetSticky(c) end
    if view.key ~= key then view.show = PAGE end
    ns:Layout()
    RenderChat("open")
    UpdateTitle()
    RenderList()
end

function ns:Refresh(key) return Safe(DoRefresh, ns, key) end
ns.Later = Later
function ns:Open(key) return Safe(DoOpen, ns, key) end

-- Close the open chat (right pane back to "pick a chat").
function ns:CloseChat()
    openKey = nil
    if settings.lastOpen then settings.lastOpen = nil end
    ns:Layout()
    RenderChat()
end

-- Delete a chat; if it is the open one, close it too.
function ns:DeleteConv(key)
    if openKey == key then ns:CloseChat() end
    Store:Delete(key)
    ns:Refresh()
end

-- A kind was switched off: leave its conversation if it is open.
function ns:CloseKind(kind)
    local c = Store:Get(openKey)
    if c and c.kind == kind then ns:CloseChat() end
end

-- Font size changed: every text, then everything drawn again.
function ns:ApplyFontScale()
    for _, f in ipairs(fonts) do ScaleFont(f) end
    ns:Redraw()
end

-- A message of this conversation changed in place (rolls): draw it again if open.
function ns:RedrawKey(key)
    if view.key == key then view.key = nil end
end

-- Theme: colors in place, everything painted with them again, crest, redraw.
function ns:ApplyTheme()
    local name = ThemeName()
    UseTheme(name)
    for _, p in ipairs(painted) do p[1]:SetColorTexture(p[2][1], p[2][2], p[2][3], p[3]) end
    for _, f in ipairs(fonts) do
        local c = rawget(f, "col")
        if c then f:SetTextColor(c[1], c[2], c[3]) end
    end
    if crest then
        if CREST[name] and pcall(crest.SetTexture, crest, CREST[name]) then
            crest:SetAlpha(0.06)
            crest:Show()
        else
            crest:Hide()
        end
    end
    ns.theme = name
    if phone then ns:Redraw() end
end

-- Draw everything again (colors changed).
function ns:Redraw()
    view.key = nil
    ns:Refresh()
end

function ns:Back()
    openKey = nil
    ns:Layout()
    ns:Refresh()
end

function ns:IsOpen(key)
    return phone and phone:IsShown() and (not settings.min or ns.peek) and openKey == key
end

-- Drawer button: the game's arrow icons (back = collapse, forward = expand);
-- older art (spellbook page arrows) when this client has no such atlas.
local DRAWER_ART = {
    [false] = { atlas = "common-icon-backarrow", file = "Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up" },
    [true] = { atlas = "common-icon-forwardarrow", file = "Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up" },
}
function ns:DrawerIcon(collapsed)
    local b = ns.headButtons and ns.headButtons.drawer
    if not b then return end
    collapsed = collapsed and true or false
    local art = DRAWER_ART[collapsed]
    local hasAtlas = C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(art.atlas)
    if hasAtlas and b.icon.SetAtlas then
        b.icon:SetTexCoord(0, 1, 0, 1)
        b.icon:SetAtlas(art.atlas)
        b.icon:SetSize(14, 14)
        b.art = art.atlas
    else
        b.icon:SetTexture(art.file)
        b.icon:SetTexCoord(0.2, 0.8, 0.2, 0.8)  -- the arrow without the round button
        b.icon:SetSize(18, 18)
        b.art = art.file
    end
    b.icon:SetVertexColor(COL.sub[1], COL.sub[2], COL.sub[3])
    b.state = collapsed and "collapsed" or "open"
end

-- Drawer: the chats list shrinks to its icons (with the chat's initials) and back.
local drawerAnim
function ns:SetCollapsed(v)
    settings.listCollapsed = v and true or false   -- (false kept: the default is collapsed)
    if not phone then return end
    local from, to = Num(listView:GetWidth(), v and LIST_W or COLL_W), ListW()
    local dur = tonumber(settings.animTime) or 0.25
    local min = settings.min and not ns.peek
    if not drawerAnim then
        drawerAnim = CreateFrame("Frame")
        drawerAnim:Hide()
        drawerAnim:SetScript("OnUpdate", function(self, el)
            self.t = self.t + (el or 0)
            local p = math.min(1, self.t / self.dur)
            p = 1 - (1 - p) * (1 - p)
            listView:SetWidth(self.from + (self.to - self.from) * p)
            if p >= 1 then
                self:Hide()
                ns.listAnimating = nil
                ns:Layout()
                ns:Refresh()
            end
        end)
    end
    if settings.animate and dur > 0 and not min and phone:IsShown() and math.abs(from - to) >= 1 then
        drawerAnim.from, drawerAnim.to, drawerAnim.t, drawerAnim.dur = from, to, 0, dur
        ns.listAnimating = true
        ns:Layout()
        RenderList()
        drawerAnim:Show()
    else
        drawerAnim:Hide()
        ns.listAnimating = nil
        ns:Layout()
        ns:Refresh()
    end
end

function ns:Minimize(v)
    if ns.peek then -- "_" while opened by the mouse: back to minimized
        ns.peek = false
        ns.holdPeek = true -- not again until the mouse leaves
        settings.min = true
        ns:Layout()
        UpdatePills()
        return
    end
    if v == nil then v = not settings.min end
    if InCombatLockdown and InCombatLockdown() and ns.combatMin and not v then ns.combatMin = nil end -- restored by hand in combat
    settings.min = v and true or false
    if v then ns.holdPeek = true end -- minimized by hand: no hover-open until the mouse leaves
    ns:Layout()
    UpdatePills()
    if not v then ns:Refresh() end
end

-- Minimized + option: the mouse over the phone opens it, leaving closes it again
-- (not while typing or with a menu open). Polled: child frames eat OnEnter/OnLeave.
local hover = CreateFrame("Frame", nil, UIParent)
local acc, outFor = 0, 0
local function MenuOpen()
    if Menu and Menu.GetManager then
        local ok, m = pcall(function() return Menu.GetManager():GetOpenMenu() end)
        return ok and m ~= nil
    end
end
function ns:HoverTick(dt)
    if not phone then return end
    ns.hoverTicks = (ns.hoverTicks or 0) + 1
    -- idle: no mouse over the phone, no typing, no menu for settings.idleMinutes -> minimize
    do
        local now = GetTime()
        local overNow = phone.IsMouseOver and phone:IsMouseOver()
        local e = EditBox()
        if overNow or (e and e.HasFocus and e:HasFocus()) or MenuOpen() or not ns.lastActive then ns.lastActive = now end
        local idle = tonumber(settings.idleMinutes) or 0
        if idle > 0 and not settings.min and phone:IsShown() and now - ns.lastActive > idle * 60 then
            ns.lastActive = now
            ns:Minimize(true)
            ns.holdPeek = nil
        end
    end
    if not (settings.min and settings.hoverExpand and phone:IsShown()) then
        if ns.peek then ns.peek = false; ns:Layout() end
        return
    end
    local over
    if phone.IsMouseOver then over = phone:IsMouseOver() elseif MouseIsOver then over = MouseIsOver(phone) end
    if not over then ns.holdPeek = nil end
    if over and ns.peek and IsMouseButtonDown and (IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")) then
        -- a click while it is open by the mouse: restored for good
        ns.peek = false
        settings.min = false
        ns:Layout()
        ns:Refresh()
        return
    end
    if over then
        outFor = 0 -- (opening is done by the pills: mouse over a pill)
    elseif ns.peek then
        local e = EditBox()
        if (e and e.HasFocus and e:HasFocus()) or MenuOpen() then outFor = 0 return end
        outFor = outFor + dt
        if outFor >= 0.5 then
            outFor = 0
            ns.peek = false
            ns:Layout()
            UpdateTitle()
        end
    end
end
hover:SetScript("OnUpdate", function(_, elapsed)
    acc = acc + elapsed
    if acc < 0.1 then return end
    local dt = acc
    acc = 0
    Safe(ns.HoverTick, ns, dt)
end)

function ns:Toggle()
    if settings.replaceChat then
        ns:Minimize()
    else
        settings.shown = not phone:IsShown()
        phone:SetShown(settings.shown)
    end
end

local function UpdateStatus()
    if not phone then return end
    clockText:SetText(date("%H:%M"))
    -- my money right after the clock (option showMoney), with the coin icons
    local c = GetMoney and GetMoney()
    if settings and settings.showMoney ~= false and type(c) == "number" and not (issecretvalue and issecretvalue(c)) then
        moneyText:SetText(Coins(c))
    else
        moneyText:SetText("")
    end
    zoneText:SetText((GetMinimapZoneText and GetMinimapZoneText()) or (GetRealZoneText and GetRealZoneText()) or "")
end

local function SavePoint()
    local p, _, rp, x, y = phone:GetPoint(1)
    if type(p) == "string" then settings.point = { p, rp, x, y } end
end

local function Place()
    phone:ClearAllPoints()
    local pt = settings.point
    if pt then
        phone:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
    else
        phone:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 32, 96)
    end
    phone:SetSize(settings.w, settings.min and MiniH() or settings.h)
end
ns.Place = Place

---------------------------------------------------------------------------
-- Build
---------------------------------------------------------------------------
-- onClick: a left click that was not a drag.
local function Drag(f, onClick)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self)
        self.dragged = true
        if not settings.locked then phone:StartMoving() end
    end)
    f:SetScript("OnDragStop", function() phone:StopMovingOrSizing(); SavePoint() end)
    if onClick then
        f:SetScript("OnMouseDown", function(self) self.dragged = false end)
        f:SetScript("OnMouseUp", function(self, button)
            if button == "LeftButton" and not self.dragged then Safe(onClick) end
            self.dragged = false
        end)
    end
end

local function Header(parent, onClick)
    local h = CreateFrame("Frame", nil, parent)
    h:SetPoint("TOPLEFT")
    h:SetPoint("TOPRIGHT")
    h:SetHeight(HEAD_H)
    Tex(h, "BACKGROUND", COL.head):SetAllPoints()
    Drag(h, onClick)
    return h
end

local function Build()
    phone = CreateFrame("Frame", "MilkshaksonPhoneFrame", UIParent)
    phone:SetFrameStrata("LOW")
    phone:SetClampedToScreen(true)
    phone:SetMovable(true)
    phone:SetResizable(true)
    if phone.SetClipsChildren then phone:SetClipsChildren(true) end -- content stays inside while the height moves
    phone:EnableMouse(true)
    if phone.SetResizeBounds then phone:SetResizeBounds(250, 260, 700, 1000) end
    Tex(phone, "BACKGROUND", COL.bg, 0.97):SetAllPoints()

    local status = CreateFrame("Frame", nil, phone)
    status:SetPoint("TOPLEFT")
    status:SetPoint("TOPRIGHT")
    status:SetHeight(STATUS_H)
    Tex(status, "BACKGROUND", COL.status):SetAllPoints()
    Drag(status)
    clockText = Font(status, "GameFontHighlightSmall", COL.text)
    clockText:SetPoint("LEFT", 10, 0)
    moneyText = Font(status, "GameFontHighlightSmall", COL.text)
    moneyText:SetPoint("LEFT", clockText, "RIGHT", 10, 0)
    ns.moneyText = moneyText
    zoneText = Font(status, "GameFontHighlightSmall", COL.sub, "RIGHT")
    zoneText:SetPoint("RIGHT", -10, 0)
    zoneText:SetPoint("LEFT", moneyText, "RIGHT", 10, 0)
    zoneText:SetWordWrap(false)

    -- Bottom: the bar the game's edit box sits on.
    inputBar = CreateFrame("Button", nil, phone)
    inputBar:SetPoint("BOTTOMLEFT", 6, 6)
    inputBar:SetPoint("BOTTOMRIGHT", -20, 6)
    inputBar:SetHeight(INPUT_H)
    Tex(inputBar, "BACKGROUND", COL.input):SetAllPoints()
    inputText = Font(inputBar, "GameFontHighlight", COL.sub)
    inputText:SetPoint("LEFT", 12, 0)
    inputText:SetPoint("RIGHT", -8, 0)
    inputText:SetWordWrap(false)
    inputBar:SetScript("OnClick", function() ns:Compose() end)

    -- List
    listView = CreateFrame("Frame", nil, phone)
    if listView.SetClipsChildren then listView:SetClipsChildren(true) end -- rows stay inside while the drawer slides
    listView:SetPoint("TOPLEFT", status, "BOTTOMLEFT", 0, -TOP_H - SEARCH_H)
    listView:SetPoint("BOTTOMRIGHT", phone, "BOTTOMRIGHT", 0, INPUT_H + 10)
    -- Top bar over both panes (the chat's own header is inside its pane).
    -- Minimized: a click on "Chats" restores the phone.
    local function Restore()
        if settings.min then
            ns.peek = false
            ns:Minimize(false)
        end
    end
    local lh = Header(phone, Restore)
    lh:ClearAllPoints()
    lh:SetPoint("TOPLEFT", status, "BOTTOMLEFT")
    lh:SetPoint("TOPRIGHT", status, "BOTTOMRIGHT")
    lh:SetHeight(TOP_H)
    local lhLine = Tex(lh, "BORDER", COL.sep)
    lhLine:SetHeight(1)
    lhLine:SetPoint("BOTTOMLEFT")
    lhLine:SetPoint("BOTTOMRIGHT")
    listHead = lh
    -- minimized: the row under the top bar ("Chats (n)" + pills) restores on click, like the bar
    local miniRow = CreateFrame("Frame", nil, phone)
    miniRow:SetPoint("TOPLEFT", lh, "BOTTOMLEFT")
    miniRow:SetPoint("TOPRIGHT", lh, "BOTTOMRIGHT")
    miniRow:SetHeight(MINI_ROW)
    miniRow:SetFrameLevel(lh:GetFrameLevel())
    Drag(miniRow, Restore)
    miniRow:Hide()
    ns.miniRow = miniRow
    listTitle = Font(lh, "GameFontNormalLarge", COL.text)
    listTitle:SetPoint("LEFT", lh, "BOTTOMLEFT", 12, -math.floor(MINI_ROW / 2))
    local minB = MinButton(lh)
    minB:SetPoint("RIGHT", -10, 0)
    -- options: always here (also minimized and with the Combat chat open)
    -- options: the gear, as in every Milkshakson window
    local cfgL = CreateFrame("Button", nil, lh)
    cfgL:SetSize(18, 18)
    cfgL:SetNormalTexture("Interface\\Buttons\\UI-OptionsButton")
    cfgL:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    cfgL:SetScript("OnClick", function() ns:OpenOptions() end)
    cfgL:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(L.TIP_OPTIONS)
        GameTooltip:Show()
    end)
    cfgL:SetScript("OnLeave", GameTooltip_Hide)
    cfgL:SetPoint("RIGHT", minB, "LEFT", -8, 0)
    -- drawer: collapse the chats list to its icons / expand it again
    -- second row: drawer arrow + search box
    searchRow = CreateFrame("Frame", nil, phone)
    searchRow:SetPoint("TOPLEFT", lh, "BOTTOMLEFT")
    searchRow:SetPoint("TOPRIGHT", lh, "BOTTOMRIGHT")
    searchRow:SetHeight(SEARCH_H)
    Tex(searchRow, "BACKGROUND", COL.head):SetAllPoints()
    local srLine = Tex(searchRow, "BORDER", COL.sep)
    srLine:SetHeight(1)
    srLine:SetPoint("BOTTOMLEFT")
    srLine:SetPoint("BOTTOMRIGHT")
    Drag(searchRow)
    local drawer = CreateFrame("Button", nil, searchRow)
    drawer:SetSize(20, 26)
    drawer.icon = drawer:CreateTexture(nil, "ARTWORK")
    drawer.icon:SetSize(14, 14)
    drawer.icon:SetPoint("CENTER")
    local dhl = drawer:CreateTexture(nil, "HIGHLIGHT")
    dhl:SetAllPoints()
    dhl:SetColorTexture(1, 1, 1, 0.08)
    drawer:SetScript("OnClick", function() ns:SetCollapsed(not settings.listCollapsed) end)
    drawer:SetScript("OnEnter", function(self)
        self.icon:SetVertexColor(COL.text[1], COL.text[2], COL.text[3])
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(L.TIP_DRAWER)
        GameTooltip:Show()
    end)
    drawer:SetScript("OnLeave", function(self)
        self.icon:SetVertexColor(COL.sub[1], COL.sub[2], COL.sub[3])
        GameTooltip_Hide()
    end)
    drawer:SetPoint("LEFT", searchRow, "LEFT", math.floor((COLL_W - 20) / 2), 0)  -- over the icons column
    ns.headButtons = { min = minB, cfg = cfgL, drawer = drawer }
    -- search box, in the header (where "Chats" is while minimized)
    local sb = CreateFrame("EditBox", nil, searchRow)
    sb:SetHeight(22)
    sb:SetPoint("LEFT", drawer, "RIGHT", 10, 0)
    sb:SetWidth(LIST_W)
    sb:SetAutoFocus(false)
    sb:SetFontObject(GameFontHighlightSmall)
    sb:SetTextInsets(22, 20, 0, 0)
    Tex(sb, "BACKGROUND", COL.input):SetAllPoints()
    local mag = sb:CreateTexture(nil, "ARTWORK")
    mag:SetSize(14, 14)
    mag:SetPoint("LEFT", 5, 0)
    mag:SetTexture("Interface\\Common\\UI-Searchbox-Icon")
    local hint = Font(sb, "GameFontDisableSmall", COL.sub)
    hint:SetPoint("LEFT", 22, 0)
    hint:SetText(L.SEARCH)
    local clear = CreateFrame("Button", nil, sb)
    clear:SetSize(16, 16)
    clear:SetPoint("RIGHT", -3, 0)
    local ct = clear:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    ct:SetPoint("CENTER")
    ct:SetText("x")
    clear:Hide()
    local function Apply(text)
        text = strtrim and strtrim(text or "") or (text or "")
        ns.query = text ~= "" and text:lower() or nil
        hint:SetShown(text == "" and not sb:HasFocus())
        clear:SetShown(text ~= "")
        listScroll:SetVerticalScroll(0)
        RenderList()
        if openKey then RenderChat() end
    end
    sb:SetScript("OnTextChanged", function(self) Safe(Apply, self:GetText()) end)
    sb:SetScript("OnEscapePressed", function(self) self:SetText(""); self:ClearFocus() end)
    sb:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    sb:SetScript("OnEditFocusGained", function() hint:Hide() end)
    sb:SetScript("OnEditFocusLost", function(self) hint:SetShown((self:GetText() or "") == "") end)
    clear:SetScript("OnClick", function() sb:SetText(""); sb:ClearFocus() end)
    searchBox = sb
    ns.searchBox = sb
    -- top bar: professions (icon + level) on the left, the buttons on the right
    profBar = CreateFrame("Frame", nil, lh)
    profBar:SetPoint("TOPLEFT", lh, "TOPLEFT")
    profBar:SetPoint("BOTTOMLEFT", lh, "BOTTOMLEFT")
    profBar:SetPoint("RIGHT", cfgL, "LEFT", -6, 0)
    ns.profWidth = 0
    if profBar.SetClipsChildren then profBar:SetClipsChildren(true) end
    profBar:SetScript("OnShow", function() ns:SyncProfButtons() end)
    profBar:SetScript("OnHide", function() ns:SyncProfButtons() end)
    ns.profBar = profBar
    ns.searchRow = searchRow

    listScroll, listContent = Scroller(listView)
    listScroll:SetPoint("TOPLEFT", listView, "TOPLEFT", 0, -2)
    listScroll:SetPoint("BOTTOMRIGHT")
    emptyText = Font(listContent, "GameFontHighlightSmall", COL.sub, "CENTER")
    emptyText:SetPoint("TOPLEFT", 20, -30)
    emptyText:SetPoint("TOPRIGHT", -20, -30)
    emptyText:SetText(L.EMPTY)

    -- Conversation
    chatView = CreateFrame("Frame", nil, phone)
    chatView:SetPoint("TOPLEFT", listView, "TOPRIGHT")
    chatView:SetPoint("BOTTOMRIGHT", phone, "BOTTOMRIGHT", 0, INPUT_H + 10)
    -- faction crest, very faint, behind the messages
    crest = chatView:CreateTexture(nil, "BACKGROUND", nil, 2)
    crest:SetSize(170, 170)
    crest:SetPoint("CENTER", chatView, "CENTER", 0, -10)
    local divider = Tex(chatView, "BORDER", COL.sep)
    divider:SetWidth(1)
    divider:SetPoint("TOPLEFT")
    divider:SetPoint("BOTTOMLEFT")
    local ch = Header(chatView)
    chatIcon = ch:CreateTexture(nil, "ARTWORK")
    chatIcon:SetSize(30, 30)
    chatIcon:SetPoint("LEFT", 10, 0)
    RoundIcon(chatIcon)
    chatRing = Tex(ch, "ARTWORK", COL.ring, 0.9, -1)
    chatRing:SetSize(34, 34)
    chatRing:SetPoint("CENTER", chatIcon, "CENTER")
    Round(chatRing)
    -- (options and -/+ are in the chats header, always there)
    local copyC = CreateFrame("Button", nil, ch)
    copyC:SetSize(20, 20)
    copyC:SetPoint("RIGHT", -10, 0)
    copyC:SetNormalTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up")
    copyC:SetHighlightTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up", "ADD")
    copyC:SetScript("OnClick", function() if openKey then Safe(ns.CopyConv, ns, openKey) end end)
    copyC:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(L.COPY_CONV)
        GameTooltip:Show()
    end)
    copyC:SetScript("OnLeave", GameTooltip_Hide)
    chatTitle = Font(ch, "GameFontHighlight", COL.text)
    chatTitle:SetPoint("TOPLEFT", chatIcon, "TOPRIGHT", 8, -1)
    chatTitle:SetPoint("RIGHT", copyC, "LEFT", -4, 0)
    chatTitle:SetWordWrap(false)
    -- Click the name of a private chat: the phone's player menu.
    local who = CreateFrame("Button", nil, ch)
    who:SetPoint("TOPLEFT", chatIcon, "TOPLEFT")
    who:SetPoint("BOTTOMRIGHT", chatTitle, "BOTTOMRIGHT", 0, -16)
    who:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    who:SetScript("OnClick", function(self, button)
        local c = Store:Get(openKey)
        if c and c.kind == "whisper" and c.target then
            Safe(ns.PlayerMenu, ns, self, c.target)
        end
    end)
    who:SetScript("OnEnter", function(self)
        local c = Store:Get(openKey)
        if c and c.kind == "whisper" then
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText(L.TIP_PLAYER)
            GameTooltip:Show()
        end
    end)
    who:SetScript("OnLeave", GameTooltip_Hide)
    chatSub = Font(ch, "GameFontHighlightSmall", COL.sub)
    chatSub:SetPoint("BOTTOMLEFT", chatIcon, "BOTTOMRIGHT", 8, 1)
    chatSub:SetPoint("RIGHT", copyC, "LEFT", -4, 0)
    chatSub:SetWordWrap(false)
    chatScroll, chatContent = Scroller(chatView, function() Safe(ns.More, ns) end)

    -- Combat chat (right pane, in place of the conversation)
    local cv = ns.Combat:Build(phone, listView, INPUT_H + 10, HEAD_H)
    chatScroll:SetPoint("TOPLEFT", ch, "BOTTOMLEFT", 0, -2)
    chatScroll:SetPoint("BOTTOMRIGHT", -10, 0)   -- room for the scroll bar
    ns.chatBar = ScrollBar(chatScroll, function() Safe(ns.More, ns) end)

    -- Shown while the game hides messages from addons.
    banner = CreateFrame("Frame", nil, phone)
    banner:SetPoint("TOPLEFT", status, "BOTTOMLEFT")
    banner:SetPoint("TOPRIGHT", status, "BOTTOMRIGHT")
    banner:SetHeight(44)
    banner:SetFrameLevel(phone:GetFrameLevel() + 20)
    Tex(banner, "BACKGROUND", COL.warn, 0.95):SetAllPoints()
    local bt = Font(banner, "GameFontHighlightSmall", COL.text)
    bt:SetPoint("TOPLEFT", 8, -4)
    bt:SetPoint("BOTTOMRIGHT", -8, 4)
    bt:SetText(L.BLOCKED)
    banner:Hide()

    errorBox = CreateFrame("Button", nil, phone)
    errorBox:SetPoint("TOPLEFT", phone, "TOPLEFT", 6, -STATUS_H - 6)
    errorBox:SetPoint("BOTTOMRIGHT", phone, "BOTTOMRIGHT", -6, INPUT_H + 14)
    errorBox:SetFrameLevel(phone:GetFrameLevel() + 40)
    Tex(errorBox, "BACKGROUND", { 0.1, 0, 0 }, 0.95):SetAllPoints()
    errorBox.text = Font(errorBox, "GameFontHighlightSmall", COL.text)
    errorBox.text:SetPoint("TOPLEFT", 8, -8)
    errorBox.text:SetPoint("BOTTOMRIGHT", -8, 8)
    errorBox.text:SetJustifyV("TOP")
    errorBox:SetScript("OnClick", function(self) self:Hide() end)
    errorBox:Hide()

    grip = CreateFrame("Button", nil, phone)
    grip:SetSize(14, 14)
    grip:SetPoint("BOTTOMRIGHT", -3, 3)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    local function EndSizing()
        phone:StopMovingOrSizing()
        settings.w, settings.h = math.floor(Num(phone:GetWidth(), settings.w)), math.floor(Num(phone:GetHeight(), settings.h))
        SavePoint()
        ns:Refresh()
    end
    grip:SetScript("OnMouseDown", function() phone:StartSizing("BOTTOMRIGHT") end)
    grip:SetScript("OnMouseUp", EndSizing)

    -- Resize by dragging any border or corner (invisible handles over the edges).
    local EDGE, CORNER = 5, 12
    ns.sizers = {}
    local function Sizer(point, w, h)
        local s = CreateFrame("Frame", nil, phone)
        s:SetFrameLevel(phone:GetFrameLevel() + 30)
        s:EnableMouse(true)
        if w then s:SetWidth(w) end
        if h then s:SetHeight(h) end
        s:SetScript("OnMouseDown", function(_, btn)
            if btn == "LeftButton" and not settings.locked and not settings.min then phone:StartSizing(point) end
        end)
        s:SetScript("OnMouseUp", EndSizing)
        ns.sizers[#ns.sizers + 1] = s
        return s
    end
    local s = Sizer("LEFT", EDGE)
    s:SetPoint("TOPLEFT", 0, -CORNER); s:SetPoint("BOTTOMLEFT", 0, CORNER)
    s = Sizer("RIGHT", EDGE)
    s:SetPoint("TOPRIGHT", 0, -CORNER); s:SetPoint("BOTTOMRIGHT", 0, CORNER)
    s = Sizer("TOP", nil, EDGE)
    s:SetPoint("TOPLEFT", CORNER, 0); s:SetPoint("TOPRIGHT", -CORNER, 0)
    s = Sizer("BOTTOM", nil, EDGE)
    s:SetPoint("BOTTOMLEFT", CORNER, 0); s:SetPoint("BOTTOMRIGHT", -CORNER, 0)
    for _, c in ipairs({ "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT" }) do
        s = Sizer(c, CORNER, CORNER)
        s:SetPoint(c)
    end
    phone:SetScript("OnSizeChanged", function() Later() end)
    phone:SetScript("OnShow", function() Later() end)

    -- Typing (Enter) while minimized / hidden opens the phone.
    local e = EditBox()
    if e and e.HookScript then
        -- Typing (Enter, "/", "r"...) never restores a minimized phone: the box shows
        -- over the header while typing and goes away after sending / Escape.
        local function Typing()
            if not ns.docked then return end
            if not phone:IsShown() then phone:Show() end
            Safe(ns.SyncEditBox, ns)
        end
        e:HookScript("OnShow", Typing)
        e:HookScript("OnEditFocusGained", Typing) -- box always shown (chat style): Enter only focuses it
        e:HookScript("OnEditFocusLost", function()
            if ns.docked and C_Timer and C_Timer.After then C_Timer.After(0, function() Safe(ns.SyncEditBox, ns) end)
            elseif ns.docked then Safe(ns.SyncEditBox, ns) end
        end)
    end
    if hooksecurefunc and FCF_OpenTemporaryWindow then
        hooksecurefunc("FCF_OpenTemporaryWindow", function() if ns.replacing then ParkAll() end end)
    end
end

---------------------------------------------------------------------------
-- /ph probe
---------------------------------------------------------------------------
ns.PROBE = {
    "ChatFrame1", "ChatFrame1.editBox", "ChatFrame1EditBox", "GeneralDockManager", "NUM_CHAT_WINDOWS",
    "ChatFrame_OpenChat", "ChatFrameUtil.OpenChat", "ChatEdit_UpdateHeader", "ChatFrameUtil.UpdateHeader",
    "ChatEdit_ActivateChat", "FCF_OpenTemporaryWindow", "SendChatMessage", "C_ChatInfo.SendChatMessage",
    "Ambiguate", "GetPlayerInfoByGUID", "C_ClassColor.GetClassColor", "CLASS_ICON_TCOORDS",
    "C_BattleNet.GetAccountInfoByID", "ChatFrame2", "UnitPopup_OpenMenu", "FriendsFrame_ShowDropdown", "C_FriendList.SendWho", "C_FriendList.SetWhoToUi", "C_FriendList.GetWhoInfo", "GetChannelList", "GetChannelName", "JoinChannelByName", "EnumerateServerChannels", "IsInGroup", "IsInRaid", "IsInGuild", "MenuUtil.CreateContextMenu", "SetItemRef", "issecretvalue", "hooksecurefunc", "MouseIsOver",
}

local function Lookup(path)
    local v = _G
    for part in path:gmatch("[^%.]+") do
        if type(v) ~= "table" then return nil end
        v = v[part]
    end
    return v
end

function ns:Probe()
    local ok, missing = {}, {}
    for _, p in ipairs(ns.PROBE) do
        if Lookup(p) ~= nil then ok[#ok + 1] = p else missing[#missing + 1] = p end
    end
    local f = CreateFrame("Frame")
    for _, ev in ipairs(Route.EVENTS) do
        local valid
        if C_EventUtils and C_EventUtils.IsEventValid then valid = C_EventUtils.IsEventValid(ev)
        else valid = pcall(f.RegisterEvent, f, ev) end
        if not valid then missing[#missing + 1] = ev end
    end
    f:UnregisterAllEvents()
    settings.lastProbe = { t = time(), ok = table.concat(ok, ", "), missing = table.concat(missing, ", "),
        events = #Route.EVENTS, replacing = ns.replacing, docked = ns.docked }
    return ok, missing
end

---------------------------------------------------------------------------
-- Events / slash
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- /ph test: a real whisper to yourself, with a report of what came back
---------------------------------------------------------------------------
local testLog
local TEST_EVENTS = { "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_SYSTEM", "UI_ERROR_MESSAGE",
    "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN", "CHAT_MSG_AFK", "CHAT_MSG_DND" }
local testFrame = CreateFrame("Frame")
testFrame:SetScript("OnEvent", function(_, event, a1, a2)
    if not testLog then return end
    local txt = (issecretvalue and issecretvalue(a1)) and "(secret)" or tostring(a1 or "")
    if event == "UI_ERROR_MESSAGE" then txt = tostring(a2 or a1 or "") end
    testLog[#testLog + 1] = event:gsub("^CHAT_MSG_", "") .. ": " .. txt:sub(1, 80)
end)

function ns:TestWhisper()
    local me = UnitName("player")
    local fn, name
    if C_ChatInfo and C_ChatInfo.SendChatMessage then fn, name = C_ChatInfo.SendChatMessage, "C_ChatInfo.SendChatMessage"
    elseif SendChatMessage then fn, name = SendChatMessage, "SendChatMessage" end
    testLog = {}
    for _, e in ipairs(TEST_EVENTS) do pcall(testFrame.RegisterEvent, testFrame, e) end
    local head = "to: " .. tostring(me) .. "\nfunction: " .. tostring(name)
    if not fn then Notice("/ph test", head .. "\nno send function in this client") return end
    local ok, err = pcall(fn, L.TEST_TEXT, "WHISPER", nil, me)
    head = head .. "\ncall: " .. (ok and "accepted" or ("error: " .. tostring(err)))
    local function report()
        testFrame:UnregisterAllEvents()
        local lines = testLog or {}
        testLog = nil
        settings.lastTest = head .. "\n" .. table.concat(lines, "\n")
        Notice("/ph test", head .. "\n\n" .. L.TEST_BACK .. "\n" .. (#lines > 0 and table.concat(lines, "\n") or L.TEST_NOTHING))
    end
    if C_Timer and C_Timer.After then C_Timer.After(3, report) else report() end
end

local chat = CreateFrame("Frame")
chat:SetScript("OnEvent", function(_, event, ...)
    if event == "WHO_LIST_UPDATE" then Safe(ns.WhoResult, ns) return end
    if event == "CHAT_MSG_SYSTEM" then Safe(ns.WhoSystem, ns, (...)) end
    local r, why = Route:Classify(event, ...)
    if not r then
        if why == "secret" then ns:Blocked(event) end
        return
    end
    if r.kind == "system" and not (r.msg.npc and settings.showNPC or (not r.msg.npc and settings.showSystem)) then return end
    if Route.myName and Store:Char().me ~= Route.myName then Store:Char().me = Route.myName; view.key = nil end
    local old = Store:Get(r.key)
    if old and old.archived ~= nil and not (r.msg and r.msg.out) then old.archived = nil end -- a new message brings it back
    Safe(Store.Add, Store, r, ns:IsOpen(r.key))
end)

local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
local function OnEvent(self, event, ...)
    if event == "ADDON_LOADED" then
        if ... ~= ADDON then return end
        self:UnregisterEvent("ADDON_LOADED")
        Store:Init()
        settings = Store:Settings()
        ns.settings = settings
        ns:ApplyLocale(settings.locale)
        UseTheme(ThemeName())
        Build()
        Place()
        ns:ApplyTheme()
        -- Never assign the StaticPopupDialogs global itself: that taints every read of it
        -- (ESC -> StaticPopup_EscapePressed -> SpellStopCasting blocked). Only add a key.
        if StaticPopupDialogs then StaticPopupDialogs.MILKSHAKSON_PHONE_CLEAR = {
            text = "%s", button1 = YES or "Yes", button2 = NO or "No",
            timeout = 0, whileDead = true, hideOnEscape = true, showAlert = true,
            OnAccept = function() openKey = nil; Store:Clear(); ns:Layout(); print(PREFIX .. L.CLEARED) end,
        } end
        Store:OnChange(function(key)
            -- many messages per second become one redraw; the quiet System chat redraws nothing while closed
            if key == "system" and key ~= openKey and Quiet(Store:Get(key)) then return end
            Later()
        end)
        for _, e in ipairs(Route.EVENTS) do pcall(chat.RegisterEvent, chat, e) end
        pcall(chat.RegisterEvent, chat, "WHO_LIST_UPDATE")
        for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED", "ZONE_CHANGED_NEW_AREA",
            "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ENCOUNTER_END",
            "CHANNEL_UI_UPDATE", "CHAT_MSG_CHANNEL_NOTICE", "GROUP_ROSTER_UPDATE", "PLAYER_GUILD_UPDATE",
            "PLAYER_REGEN_DISABLED", "GROUP_JOINED", "SKILL_LINES_CHANGED", "TRAINER_SHOW", "PLAYER_MONEY" }) do
            pcall(self.RegisterEvent, self, e)
        end
        if settings.combatLog then ns.Combat:Start() end
        if ns.Rolls then ns.Rolls:Start() end
        if ns.Auction then ns.Auction:Start() end
        ns:BuildOptions(settings)
        if settings.replaceChat or settings.shown ~= false then phone:Show() else phone:Hide() end
        local first = settings.lastOpen or "guild"
        if Store:Get(first) or first == "guild" and IsInGuild and IsInGuild() then openKey = first end
        ns:Layout()
        ns:Refresh()
        if openKey then ns:Open(openKey) end
        UpdateStatus()
        if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(10, UpdateStatus) end
    elseif event == "PLAYER_ENTERING_WORLD" then
        ns:UpdateProfessions()
        if (settings.theme or "auto") == "auto" and ns.theme ~= ThemeName() then ns:ApplyTheme() end
        -- my name as the chat writes it (Forever: "First Last"), for my own old messages
        if UnitGUID and GetPlayerInfoByGUID then
            local ok, _, _, _, _, _, name = pcall(GetPlayerInfoByGUID, UnitGUID("player"))
            if ok and type(name) == "string" and name ~= "" then
                Route.myName = name
                if Store:Char().me ~= name then Store:Char().me = name; view.key = nil end
            end
        end
        ns.blocked = false
        banner:Hide()
        if settings.replaceChat then ApplyReplace(true) end
        UpdateStatus()
        Later()
        -- the game joins its own channels a moment after loading: join what is missing after that
        if C_Timer and C_Timer.After then
            C_Timer.After(4, function() ns:AutoJoin(); Later() end)
        else
            ns:AutoJoin()
        end
    elseif event == "TRAINER_SHOW" then
        if ns.Trainers then
            local names = {}
            for _, p in ipairs(ProfList()) do names[#names + 1] = p[1] end
            Safe(ns.Trainers.Learn, ns.Trainers, names)
        end
    elseif event == "SKILL_LINES_CHANGED" then
        ns:UpdateProfessions()
    elseif event == "PLAYER_MONEY" then
        UpdateStatus()
    elseif event == "GROUP_JOINED" then
        -- option: a new group starts with an empty group chat
        if settings.resetParty then
            for _, k in ipairs({ "party", "raid", "instance" }) do
                if Store:Get(k) then Store:ClearConv(k) end
            end
            if openKey == "party" or openKey == "raid" or openKey == "instance" then view.key = nil end
        end
        Later()
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- option: minimize when combat starts (and restore after, if combat did it)
        if settings.combatMinimize and not settings.min then
            ns.combatMin = true
            ns.peek = false
            ns:Minimize(true)
            ns.holdPeek = nil
        end
    elseif event == "PLAYER_REGEN_ENABLED" or event == "ENCOUNTER_END" or event == "ZONE_CHANGED_NEW_AREA" then
        -- the state driver shows the profession buttons after combat: hide the ones that should not be
        if event == "PLAYER_REGEN_ENABLED" and C_Timer and C_Timer.After then
            C_Timer.After(0.1, function() if profPending then ns:UpdateProfessions() else ns:SyncProfButtons() end end)
        end
        if event == "PLAYER_REGEN_ENABLED" and ns.combatMin then
            ns.combatMin = nil
            if settings.min and not ns.peek then ns:Minimize(false) end
        end
        ns:Unblock()
        if event == "PLAYER_REGEN_ENABLED" and ns.joinAfterCombat then ns:AutoJoin(); Later() end
        UpdateStatus()
        if event == "ZONE_CHANGED_NEW_AREA" then
            if C_Timer and C_Timer.After then C_Timer.After(3, function() ns:AutoJoin(); Later() end) else ns:AutoJoin() end
            Later()
        end
    elseif event == "CHANNEL_UI_UPDATE" or event == "CHAT_MSG_CHANNEL_NOTICE" or event == "GROUP_ROSTER_UPDATE" or event == "PLAYER_GUILD_UPDATE" then
        Later()
    else
        UpdateStatus()
    end
end
ev:SetScript("OnEvent", function(self, event, ...) Safe(OnEvent, self, event, ...) end)

-- Public: the Milkshakson addons put their messages in one "Milkshakson-Addons"
-- conversation on the phone (the game's chat window is hidden while the phone
-- replaces it). Optional for them: they check that this function exists.
--   MilkshaksonPhone_AddonMessage("Trader", "text")
local ADDON_KEY = "milkshakson"
function MilkshaksonPhone_AddonMessage(addon, text)
    if type(addon) ~= "string" or addon == "" or type(text) ~= "string" or not settings then return false end
    local c = Store:Ensure(ADDON_KEY, "addon", L.ADDONS_CHAT)
    c.icon = "Interface\\Icons\\INV_Misc_Coin_01"
    Safe(Store.Add, Store, { key = ADDON_KEY, kind = "addon", name = L.ADDONS_CHAT,
        msg = { t = time(), text = "|cff33ff99" .. addon .. ":|r " .. text, info = true, ev = "SYSTEM" } }, ns:IsOpen(ADDON_KEY))
    return true
end

SLASH_MILKSHAKSONPHONE1 = "/phone"
SLASH_MILKSHAKSONPHONE2 = "/mphone"
SLASH_MILKSHAKSONPHONE3 = "/ph"
SLASH_MILKSHAKSONPHONE4 = "/mph"
SlashCmdList.MILKSHAKSONPHONE = function(msg)
    msg = strtrim((msg or ""):lower())
    if msg == "" or msg == "show" then
        ns:Toggle()
    elseif msg == "config" or msg == "options" then
        ns:OpenOptions()
    elseif msg == "chat on" or msg == "chat off" or msg == "chat" then
        local on = msg == "chat on" or (msg == "chat" and not settings.replaceChat)
        ns:SetReplace(on)
        print(PREFIX .. (on and L.CHAT_ON or L.CHAT_OFF))
    elseif msg == "reset" then
        settings.point, settings.w, settings.h, settings.min = nil, Store.DEFAULTS.w, Store.DEFAULTS.h, false
        Place()
        ns:Layout()
        print(PREFIX .. L.RESET)
    elseif msg == "clear" then
        if StaticPopup_Show then StaticPopup_Show("MILKSHAKSON_PHONE_CLEAR", L.POPUP_CLEAR) end
    elseif msg == "test" then
        Safe(ns.TestWhisper, ns)
    elseif msg == "test fake" then
        -- a whisper that only exists on the phone (nothing is sent)
        local r = Route:Classify("CHAT_MSG_WHISPER", L.TEST_TEXT, L.TEST_FROM, "", "", L.TEST_FROM, "", 0, 0, "", 0, 0, "")
        if r then Safe(Store.Add, Store, r, ns:IsOpen(r.key)) end
    elseif msg == "show channels" then
        settings.hiddenChannels = nil
        ns:Refresh()
        print(PREFIX .. L.CHANNELS_SHOWN)
    elseif msg == "status" then
        local convs, msgs = Store:Counts()
        print(PREFIX .. L.STATUS:format(convs, msgs, Store:Unread(), ns.replacing and L.ON or L.OFF))
        local k = settings.lastClick
        local line = (k and ("last click: " .. k.button .. " on " .. k.who .. ", menu API: " .. k.menu) or "last click: none")
            .. "\ngame menu: " .. tostring(settings.lastMenu or "-")
            .. "\nhover: option " .. tostring(settings.hoverExpand) .. ", minimized " .. tostring(settings.min)
            .. ", mouse over " .. tostring(phone.IsMouseOver and phone:IsMouseOver()) .. ", ticks " .. tostring(ns.hoverTicks or 0)
        print(PREFIX .. line)
        if errorBox then errorBox.text:SetText(L.STATUS:format(convs, msgs, Store:Unread(), ns.replacing and L.ON or L.OFF) .. "\n" .. line .. "\n\n(click to close)"); errorBox:Show() end
    elseif msg == "drawer" or msg == "gaveta" then
        ns:SetCollapsed(not settings.listCollapsed)
    elseif msg == "rolls" then
        -- loot rolls diagnostics, also into the Milkshakson-Addons conversation
        if ns.Rolls then
            for _, line in ipairs(ns.Rolls:Report()) do
                print(PREFIX .. line)
                MilkshaksonPhone_AddonMessage("Phone", line)
            end
        end
    elseif msg == "probe" then
        local ok, missing = ns:Probe()
        print(PREFIX .. L.PROBE_OK:format(#ok, table.concat(ok, ", ")))
        print(PREFIX .. L.PROBE_MISSING:format(#missing, #missing > 0 and table.concat(missing, ", ") or "-"))
        local j = settings.lastJoin
        if j then print(PREFIX .. L.PROBE_JOIN:format(j.tried, j.joined ~= "" and j.joined or "-")) end
        local s = settings.secret
        if s then
            print(PREFIX .. L.PROBE_SECRET:format(s.n, s.ev or "?", date("%d/%m %H:%M", s.t or 0),
                s.combat and L.ON or L.OFF, tostring(s.instance or "-")))
        else
            print(PREFIX .. L.PROBE_NOSECRET)
        end
    elseif msg:match("^lang") then
        local arg = strtrim(msg:sub(5))
        local available = table.concat(ns:AvailableLocales(), ", ")
        if arg == "" or arg == "auto" then
            settings.locale = nil
            local code = ns:ApplyLocale(nil)
            print(PREFIX .. L.LANG_AUTO:format(ns.Locales[code]._name, code))
        else
            local code
            for c in pairs(ns.Locales) do if c:lower() == arg then code = c end end
            if code then
                settings.locale = code
                ns:ApplyLocale(code)
                print(PREFIX .. L.LANG_SET:format(ns.Locales[code]._name, code))
            else
                print(PREFIX .. L.LANG_UNKNOWN:format(arg, available))
            end
        end
        emptyText:SetText(L.EMPTY)
        ns:Layout()
        ns:Refresh()
    else
        print(PREFIX .. L.HELP1)
        print(PREFIX .. L.HELP2)
        print(PREFIX .. L.HELP3:format(table.concat(ns:AvailableLocales(), ", ")))
    end
end

function MilkshaksonPhone_OnAddonCompartmentClick(_, button)
    if button == "RightButton" then ns:OpenOptions() else ns:Toggle() end
end
